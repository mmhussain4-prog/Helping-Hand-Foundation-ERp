

import React, { useState, useEffect } from 'react';
import { MOCK_BENEFICIARIES, MOCK_PROJECTS, MOCK_TRANSACTIONS, MOCK_INVENTORY, MOCK_USERS } from './services/mockData';
import { UserRole, User, AppModule } from './types';
import { Dashboard } from './components/Dashboard';
import { Beneficiaries } from './components/Beneficiaries';
import { Projects } from './components/Projects';
import { AiAssistant } from './components/AiAssistant';
import { Finance } from './components/Finance';
import { AdminPanel } from './components/AdminPanel';
import { 
  LayoutDashboard, 
  Users, 
  FolderOpen, 
  Wallet, 
  Package, 
  Settings, 
  LogOut, 
  Menu,
  Bell,
  ChevronDown,
  Shield
} from 'lucide-react';

// --- Simple Nav Components ---

const NavItem = ({ icon: Icon, label, active, onClick }: any) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
      active 
        ? 'bg-blue-50 text-blue-700 font-medium' 
        : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
    }`}
  >
    <Icon className={`w-5 h-5 ${active ? 'text-blue-600' : 'text-slate-400'}`} />
    <span>{label}</span>
  </button>
);

const App = () => {
  // App State
  const [currentUser, setCurrentUser] = useState<User>(MOCK_USERS[0]);
  const [currentView, setCurrentView] = useState<AppModule>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Global Data State (Would ideally be in Context)
  const [data] = useState({
    projects: MOCK_PROJECTS,
    transactions: MOCK_TRANSACTIONS,
    beneficiaries: MOCK_BENEFICIARIES,
    inventory: MOCK_INVENTORY
  });

  // Reset view when user changes if current view is not allowed
  useEffect(() => {
    if (!currentUser.accessibleModules.includes(currentView)) {
      // Fallback to the first accessible module or dashboard
      if (currentUser.accessibleModules.length > 0) {
        setCurrentView(currentUser.accessibleModules[0]);
      } else {
        setCurrentView('dashboard'); // Fallback, though access will be denied in render
      }
    }
  }, [currentUser]);

  // Render logic based on view
  const renderContent = () => {
    if (!currentUser.accessibleModules.includes(currentView)) {
      return (
        <div className="p-8 bg-red-50 border border-red-200 rounded-xl text-red-700 flex flex-col items-center justify-center h-96 text-center">
          <Shield className="w-12 h-12 mb-4 text-red-500" />
          <h3 className="text-xl font-bold">Access Denied</h3>
          <p className="mt-2">Your role ({currentUser.role}) does not have permission to view the {currentView} module.</p>
        </div>
      );
    }

    switch (currentView) {
      case 'dashboard':
        return <Dashboard projects={data.projects} transactions={data.transactions} beneficiaries={data.beneficiaries} currentUser={currentUser} />;
      case 'beneficiaries':
        return <Beneficiaries data={data.beneficiaries} currentUser={currentUser} />;
      case 'projects':
        // Filter projects if Program Manager is restricted to specific ones
        const userProjects = (currentUser.role === 'Program Manager' && !currentUser.assignedProjects.includes('All'))
          ? data.projects.filter(p => currentUser.assignedProjects.includes(p.id))
          : data.projects;
        return <Projects data={userProjects} />;
      case 'finance':
        return <Finance transactions={data.transactions} />;
      case 'inventory':
        return (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
             <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-600 font-medium border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4">Item</th>
                  <th className="px-6 py-4">Category</th>
                  <th className="px-6 py-4">Stock</th>
                  <th className="px-6 py-4">Location</th>
                  <th className="px-6 py-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.inventory.map(item => (
                  <tr key={item.id} className="hover:bg-slate-50">
                    <td className="px-6 py-4 font-medium text-slate-900">{item.name}</td>
                    <td className="px-6 py-4 text-slate-500">{item.category}</td>
                    <td className="px-6 py-4">{item.quantity} {item.unit}</td>
                    <td className="px-6 py-4 text-slate-500">{item.location}</td>
                    <td className="px-6 py-4">
                      {item.quantity <= item.reorderLevel ? (
                        <span className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-bold">Low Stock</span>
                      ) : (
                        <span className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full text-xs">In Stock</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case 'admin':
        return <AdminPanel />;
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-30 w-64 bg-white border-r border-slate-200 transform transition-transform duration-300 lg:translate-x-0 lg:static lg:inset-auto ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center h-16 px-6 border-b border-slate-100">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
            <span className="text-white font-bold text-lg">H</span>
          </div>
          <span className="font-bold text-xl text-slate-800 tracking-tight">Helping Hand</span>
        </div>

        <div className="p-4 space-y-1">
          {currentUser.accessibleModules.includes('dashboard') && (
            <NavItem icon={LayoutDashboard} label="Dashboard" active={currentView === 'dashboard'} onClick={() => setCurrentView('dashboard')} />
          )}
          {currentUser.accessibleModules.includes('beneficiaries') && (
            <NavItem icon={Users} label="Beneficiaries" active={currentView === 'beneficiaries'} onClick={() => setCurrentView('beneficiaries')} />
          )}
          {currentUser.accessibleModules.includes('projects') && (
            <NavItem icon={FolderOpen} label="Projects" active={currentView === 'projects'} onClick={() => setCurrentView('projects')} />
          )}
          {currentUser.accessibleModules.includes('finance') && (
            <NavItem icon={Wallet} label="Finance & Grants" active={currentView === 'finance'} onClick={() => setCurrentView('finance')} />
          )}
          {currentUser.accessibleModules.includes('inventory') && (
            <NavItem icon={Package} label="Inventory" active={currentView === 'inventory'} onClick={() => setCurrentView('inventory')} />
          )}
          
          <div className="pt-4 pb-2">
            <div className="h-px bg-slate-100 mx-2"></div>
          </div>
          
          {currentUser.accessibleModules.includes('admin') && (
            <NavItem icon={Shield} label="Admin Panel" active={currentView === 'admin'} onClick={() => setCurrentView('admin')} />
          )}
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-3 mb-4 px-2">
             <div className="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-xs">
                {currentUser.name.charAt(0)}
             </div>
             <div className="overflow-hidden">
                <div className="text-sm font-medium text-slate-900 truncate">{currentUser.name}</div>
                <div className="text-xs text-slate-500 truncate">{currentUser.role}</div>
             </div>
          </div>
          <button className="flex items-center space-x-3 text-slate-500 hover:text-red-600 w-full px-2 py-2 rounded-lg transition-colors mt-1">
            <LogOut className="w-5 h-5" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8 sticky top-0 z-20">
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden p-2 text-slate-500 hover:bg-slate-100 rounded-lg">
            <Menu className="w-6 h-6" />
          </button>

          <div className="flex items-center space-x-4 ml-auto">
            {/* User Switcher for Demo */}
            <div className="hidden md:flex items-center gap-2 mr-4">
              <span className="text-xs font-bold text-slate-400 uppercase">Switch User:</span>
              <div className="flex bg-slate-100 rounded-lg p-1">
                {MOCK_USERS.map(u => (
                  <button
                    key={u.id}
                    onClick={() => setCurrentUser(u)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${currentUser.id === u.id ? 'bg-white shadow text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}
                    title={`Role: ${u.role}`}
                  >
                    {u.name.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            <button className="relative p-2 text-slate-400 hover:text-slate-600 transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>

            <div className="flex items-center pl-4 border-l border-slate-200">
              <div className="h-8 w-8 bg-gradient-to-tr from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-sm">
                {currentUser.name.substring(0, 2).toUpperCase()}
              </div>
              <ChevronDown className="w-4 h-4 text-slate-400 ml-2 hidden md:block" />
            </div>
          </div>
        </header>

        {/* Scrollable View Area */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-8 scroll-smooth">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>

        {/* AI Assistant Overlay */}
        <AiAssistant context={data} />

      </div>
      
      {/* Mobile Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 z-20 bg-slate-900/20 backdrop-blur-sm lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        ></div>
      )}
    </div>
  );
};

export default App;
