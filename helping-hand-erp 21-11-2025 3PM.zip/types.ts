

export enum UserRole {
  ADMIN = 'Admin',
  TRUSTEE = 'Trustee',
  FINANCE = 'Finance Controller',
  OPS = 'Operations',
  VOLUNTEER = 'Volunteer',
  PROGRAM_MANAGER = 'Program Manager',
  ACCOUNTANT = 'Accountant'
}

export enum Status {
  ACTIVE = 'Active',
  PENDING = 'Pending',
  COMPLETED = 'Completed',
  ARCHIVED = 'Archived',
  CRITICAL = 'Critical'
}

// New Case Types for Granular Management
export enum CaseType {
  MEDICAL = 'Medical Support',
  FINANCIAL = 'Financial Support',
  MARRIAGE = 'Marriage Support',
  WIDOW = 'Widow Support',
  EDUCATION = 'Orphan/Education Support'
}

export enum Priority {
  GENERAL = 'General',
  EMERGENCY = 'Emergency',
  URGENT = 'Urgent'
}

// Project Classification
export type ProjectNature = 'FCRA' | 'CSR' | 'Family Philanthropy' | 'Local Donations';
export type ProjectCategory = 'Medical' | 'Scholarships' | 'Educational Support' | 'HHF School' | 'Other';

// Sub-categories for specific logic
export type MedicalSubCategory = 'Surgery' | 'Medicines' | 'Blood' | 'Hospital Stay' | 'Dialysis' | 'Other';

// Workflow Status
export enum CaseStatus {
  DRAFT = 'Draft',
  SUBMITTED = 'Submitted', // Volunteer submits -> Pending Finance
  VERIFIED = 'Verified', // Coordinator/Ops verifies
  APPROVED = 'Approved', // Finance/Trustee approves -> Pending Payment
  REJECTED = 'Rejected',
  DISBURSED = 'Disbursed', // Accountant confirms payment -> Pending Confirmation
  ACKNOWLEDGED = 'Acknowledged', // Volunteer confirms receipt -> Closed
  CLOSED = 'Closed'
}

export interface FamilyMember {
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  relation: string;
  isAdult: boolean; // To determine if education is 'Schooling' or 'Highest Degree'
  education: string; // Schooling details if minor, Qualification if adult
  occupation: string;
  earnings: number; // Renamed from monthlyIncome for clarity
}

export interface FinancialItem {
  id: string;
  label: string;
  amount: number;
}

export interface FinancialArrangement {
  totalCost: number;
  ownContribution: number;
  otherDonors: number;
  requestedAmount: number;
  details: string; // How they arranged the rest
}

export interface Beneficiary {
  id: string;
  name: string;
  contact: string;
  location: string;
  address?: string;
  photoUrl?: string;
  caseType: CaseType;
  subCategory?: string;
  status: CaseStatus | Status; // Compatible with old Status enum for now
  priority: Priority;
  lastInteraction: string;
  impactScore: number;
  
  // Payment & Workflow
  paymentType: 'One-Time' | 'Recurring';
  recurringStartDate?: string;
  recurringEndDate?: string;
  transactionId?: string;

  // Linkage
  projectId?: string; // To link beneficiary to a specific project (Program Manager scope)

  // Detailed Fields
  familyMembers?: FamilyMember[];
  financials?: FinancialArrangement;
  
  // Socio-Economic Data
  housingStatus?: 'Own' | 'Rent' | 'Free/Relative' | 'Homeless';
  rentAmount?: number;
  electricityBill?: number;
  incomeSources?: FinancialItem[];
  monthlyExpenses?: FinancialItem[];
  assets?: string;
  liabilities?: string;
  coordinatorRecommendation?: string;

  documents?: string[]; // List of document names
  
  // Workflow tracks
  assignedVolunteer?: string;
  approvedBy?: string;
  paymentDate?: string;
}

export interface Project {
  id: string;
  name: string;
  nature: ProjectNature;
  category: ProjectCategory;
  status: Status;
  manager: string;
  
  // Financials
  approvedBudget: number;      // The budget approved for the current cycle
  carryForward: number;        // Funds remaining from previous month/year
  monthlyExpenses: number;     // Average or current month expenses
  spent: number;               // Total spent YTD
  predictedBudget: number;     // Next year's prediction based on trends
  
  // Derived/Display helpers
  description?: string;
  lastReportDate?: string;
}

export type PaymentMode = 'NEFT/RTGS' | 'Cheque' | 'Cash' | 'UPI' | 'Demand Draft';

export interface Transaction {
  id: string;
  date: string;
  type: 'Donation' | 'Expense' | 'Grant' | 'Salary';
  description: string;
  category: string; // General Ledger Head (e.g., 'Rent', 'Medical Aid')
  
  // Amount Breakdown for Indian Accounting
  amount: number; // This is usually the Net Amount affecting the bank
  grossAmount?: number;
  tdsDeducted?: number;
  tdsSection?: string; // e.g. 194C, 194J
  
  // Cost Centers
  linkedProjectId?: string;
  linkedBeneficiaryId?: string;
  
  // Banking
  paymentMode: PaymentMode;
  bankReference?: string; // Cheque No. or UTR
  reconciled: boolean;
  
  invoiceUrl?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  reorderLevel: number;
  location: string;
}

export interface ComplianceRecord {
  id: string;
  type: 'TDS Return' | 'GST Return' | 'FCRA Annual' | 'IT Return' | 'PF Filing';
  period: string; // e.g. Q3 2023
  dueDate: string;
  status: 'Pending' | 'Filed' | 'Overdue';
  filedDate?: string;
  acknowledgementNo?: string;
}

export interface BankStatementUpload {
  id: string;
  fileName: string;
  uploadDate: string;
  status: 'Processed' | 'Pending Reconciliation';
  month: string;
}

// --- ADMIN & CONTROLS ---

export type ControlArea = 
  | 'Donation Receipts' 
  | 'Project Expenditure' 
  | 'Procurement' 
  | 'Payroll & HR' 
  | 'Fixed Assets' 
  | 'Cash & Banking' 
  | 'Compliance' 
  | 'Budgeting' 
  | 'IT Systems';

export interface InternalControl {
  id: string;
  area: ControlArea;
  risk: string;
  controlActivity: string;
  owner: string; // e.g. "Finance Head"
  testingMethod: string; // "Verify 100% of..."
  status: 'Compliant' | 'Flagged' | 'Pending';
  lastVerified?: string;
}

export interface UserPermissions {
  canCreateUsers: boolean;
  canApproveBudget: boolean;
  canSignCheques: boolean;
  canAccessFCRA: boolean;
  canViewPayroll: boolean;
  canApproveVendors: boolean;
  canVerifyStock: boolean;
}

export type AppModule = 'dashboard' | 'beneficiaries' | 'projects' | 'finance' | 'inventory' | 'admin';

export interface RoleDefinition {
  id: string;
  name: string;
  description: string;
  accessibleModules: AppModule[];
  permissions: UserPermissions;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: string; // Custom string allowed e.g. "Program Head"
  assignedProjects: string[]; // List of Project IDs they can access
  accessibleModules: AppModule[]; // New field for dashboard control
  permissions: UserPermissions;
  status: 'Active' | 'Inactive';
  department: string;
}

export interface SystemSettings {
  orgName: string;
  fiscalYear: string;
  enableAiAssistant: boolean;
  maintenanceMode: boolean;
  allowVolunteerSignups: boolean;
}