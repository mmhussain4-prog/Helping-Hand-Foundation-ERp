
import React from 'react';
import { Shield, Database, Lock, Server, Users, Code } from 'lucide-react';

export const SystemInfo: React.FC = () => {
  
  const roleMatrix = [
    { role: 'Admin', access: 'Full Access', desc: 'User Setup, Configuration, All Modules' },
    { role: 'Trustee', access: 'Oversight', desc: 'View Reports, Approve Budgets >$10k, Read-only Projects' },
    { role: 'Finance Controller', access: 'Financials', desc: 'Journal Entries, Reconciliations, Payroll, FCRA Reporting' },
    { role: 'Operations', access: 'Execution', desc: 'Task Assignment, Beneficiary Updates, Survey Deployment' },
    { role: 'Volunteer', access: 'Limited', desc: 'View Tasks, Submit Timesheets (No Financial Access)' },
  ];

  const dbSchemas = [
    {
      title: 'Beneficiary Schema',
      code: `interface Beneficiary {
  id: string;           // Unique ID (e.g., B001)
  name: string;         // Full Name
  location: string;     // Geolocation or District
  needs: string[];      // Array of tags (e.g. ['Housing'])
  status: Status;       // Active, Pending, Critical
  lastInteraction: Date;// ISO String
  impactScore: number;  // 0-100 AI Calculated Score
}`
    },
    {
      title: 'Project Schema (FCRA/CSR)',
      code: `interface Project {
  id: string;
  name: string;
  type: 'FCRA' | 'CSR' | 'General'; // Project Funding Source
  budget: number;
  spent: number;
  status: Status;
  manager: string;      // User ID Link
  complianceDocs: string[]; // Links to PDF uploads
}`
    },
    {
      title: 'Transaction Schema',
      code: `interface Transaction {
  id: string;
  date: string;
  type: 'Donation' | 'Expense' | 'Grant';
  amount: number;
  category: string;     // e.g., 'FCRA', 'CSR', 'Admin'
  description: string;
  donorId?: string;     // Optional link to Donor DB
  projectId?: string;   // Allocation to specific project
}`
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-3">
          <Server className="w-8 h-8 text-blue-600" />
          System & Database Architecture
        </h2>
        <p className="text-slate-500 mt-2 max-w-3xl">
          This module provides a technical overview of the ERP's access control layers and data models. 
          Use this reference to validate data structures against FCRA/CSR compliance requirements.
        </p>
      </div>

      {/* Access Control Matrix */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
          <div>
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-600" />
              Role-Based Access Control (Logins)
            </h3>
            <p className="text-sm text-slate-500 mt-1">Test these roles using the dropdown in the top-right header.</p>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-600 font-medium border-b border-slate-200">
              <tr>
                <th className="px-6 py-4">Role / Login</th>
                <th className="px-6 py-4">Access Level</th>
                <th className="px-6 py-4">Key Permissions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {roleMatrix.map((r, i) => (
                <tr key={i} className="hover:bg-slate-50">
                  <td className="px-6 py-4 font-bold text-slate-800 flex items-center gap-2">
                    <Users className="w-4 h-4 text-slate-400" /> {r.role}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      r.role === 'Admin' ? 'bg-purple-100 text-purple-700' : 
                      r.role === 'Volunteer' ? 'bg-slate-100 text-slate-600' : 'bg-blue-50 text-blue-700'
                    }`}>
                      {r.access}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-600">{r.desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Database Structure */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="lg:col-span-2">
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 mb-4">
            <Database className="w-5 h-5 text-blue-600" />
            Core Data Schemas
          </h3>
        </div>
        
        {dbSchemas.map((schema, i) => (
          <div key={i} className="bg-slate-900 rounded-xl overflow-hidden border border-slate-800 shadow-md">
            <div className="px-4 py-3 bg-slate-800 border-b border-slate-700 flex justify-between items-center">
              <span className="text-slate-200 font-medium text-sm flex items-center gap-2">
                <Code className="w-4 h-4" /> {schema.title}
              </span>
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/50"></div>
                <div className="w-3 h-3 rounded-full bg-emerald-500/20 border border-emerald-500/50"></div>
              </div>
            </div>
            <div className="p-4 overflow-x-auto">
              <pre className="text-xs font-mono text-blue-200 leading-relaxed">
                {schema.code}
              </pre>
            </div>
          </div>
        ))}
      </div>

      {/* Improv Suggestions */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
        <h4 className="text-amber-800 font-bold flex items-center gap-2 mb-2">
          <Lock className="w-5 h-5" />
          Testing Notes for Improvisation
        </h4>
        <ul className="list-disc list-inside text-sm text-amber-900 space-y-1">
          <li><strong>FCRA Segregation:</strong> Ensure `Transaction` schema enforces a strict project link for all foreign contributions.</li>
          <li><strong>CSR Compliance:</strong> Verify that `Project` schema allows attaching impact assessment documents required by CSR laws.</li>
          <li><strong>Audit Trail:</strong> Current mock data lacks an `AuditLog` schema which is critical for 80G/12A compliance.</li>
        </ul>
      </div>

    </div>
  );
};
