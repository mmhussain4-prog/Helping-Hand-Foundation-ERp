
import React, { useState } from 'react';
import { Beneficiary, Status, CaseStatus, CaseType, Priority, User, UserRole } from '../types';
import { Search, Filter, MoreHorizontal, MapPin, Plus, CheckCircle, Clock, AlertTriangle, Banknote, Eye, ArrowRight, ShieldCheck, Lock } from 'lucide-react';
import { AddCaseForm } from './AddCaseForm';
import { BeneficiaryDetails } from './BeneficiaryDetails';

interface Props {
  data: Beneficiary[];
  currentUser: User;
}

export const Beneficiaries: React.FC<Props> = ({ data, currentUser }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [selectedBeneficiary, setSelectedBeneficiary] = useState<Beneficiary | null>(null);
  const [filter, setFilter] = useState('');
  const [transactionInputId, setTransactionInputId] = useState<string | null>(null);
  const [transactionValue, setTransactionValue] = useState('');

  // Simulated Local Data for UI Demo
  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>(data.map(b => ({
    ...b,
    // Normalize old mock status to new enum if necessary
    status: b.status
  })));

  const filteredData = beneficiaries.filter(b => 
    b.name.toLowerCase().includes(filter.toLowerCase()) ||
    b.location.toLowerCase().includes(filter.toLowerCase())
  );

  // --- Workflow Handlers ---

  const handleAddSubmit = (newData: any) => {
    const newBeneficiary: Beneficiary = {
      id: `B${Math.floor(Math.random() * 10000)}`,
      name: newData.name,
      location: newData.location,
      contact: newData.contact,
      address: newData.address,
      status: CaseStatus.SUBMITTED, // Default start state
      caseType: newData.caseType,
      priority: newData.priority,
      subCategory: newData.subCategory,
      impactScore: 0,
      paymentType: newData.paymentType,
      recurringStartDate: newData.recurringStartDate,
      recurringEndDate: newData.recurringEndDate,
      lastInteraction: new Date().toISOString().split('T')[0],
      documents: newData.documents,
      financials: newData.financials,
      familyMembers: newData.familyMembers,
      housingStatus: newData.housingDetails.status,
      rentAmount: newData.housingDetails.rentAmount,
      electricityBill: newData.housingDetails.electricityBill,
      incomeSources: newData.incomeSources,
      monthlyExpenses: newData.monthlyExpenses,
      assets: newData.assetLiability.assets,
      liabilities: newData.assetLiability.liabilities,
      coordinatorRecommendation: newData.coordinatorRecommendation
    };
    setBeneficiaries([newBeneficiary, ...beneficiaries]);
    setIsAdding(false);
  };

  const updateStatus = (id: string, newStatus: CaseStatus | Status, extraData?: Partial<Beneficiary>) => {
     setBeneficiaries(prev => prev.map(b => b.id === id ? { ...b, status: newStatus, ...extraData } : b));
     if (transactionInputId === id) {
       setTransactionInputId(null);
       setTransactionValue('');
     }
  };

  const getStatusBadge = (status: CaseStatus | Status) => {
    switch (status) {
      case CaseStatus.DRAFT:
        return <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-full text-xs font-medium border border-slate-200 flex items-center gap-1"><Clock className="w-3 h-3" /> Draft</span>;
      case CaseStatus.SUBMITTED:
      case Status.PENDING:
        return <span className="bg-blue-50 text-blue-700 px-2 py-1 rounded-full text-xs font-medium border border-blue-100 flex items-center gap-1"><Clock className="w-3 h-3" /> Finance Review</span>;
      case CaseStatus.APPROVED:
        return <span className="bg-purple-50 text-purple-700 px-2 py-1 rounded-full text-xs font-bold border border-purple-100 flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> Approved (Pay)</span>;
      case CaseStatus.DISBURSED:
        return <span className="bg-emerald-50 text-emerald-700 px-2 py-1 rounded-full text-xs font-medium border border-emerald-100 flex items-center gap-1"><Banknote className="w-3 h-3" /> Paid</span>;
      case CaseStatus.ACKNOWLEDGED:
      case CaseStatus.CLOSED:
      case Status.COMPLETED:
        return <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-full text-xs font-medium border border-slate-200 flex items-center gap-1"><CheckCircle className="w-3 h-3" /> Closed</span>;
      case CaseStatus.REJECTED:
        return <span className="bg-red-50 text-red-700 px-2 py-1 rounded-full text-xs font-medium border border-red-100 flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> Rejected</span>;
      default:
        return <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-full text-xs">{status}</span>;
    }
  };

  const getPriorityBadge = (priority: Priority) => {
    switch (priority) {
      case Priority.URGENT:
        return <span className="text-[10px] font-bold text-white bg-red-500 px-1.5 py-0.5 rounded">URGENT</span>;
      case Priority.EMERGENCY:
        return <span className="text-[10px] font-bold text-white bg-amber-500 px-1.5 py-0.5 rounded">EMERGENCY</span>;
      default:
        return <span className="text-[10px] font-medium text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">General</span>;
    }
  };

  // --- Render Workflow Actions ---
  const renderActions = (item: Beneficiary) => {
    const role = currentUser.role;
    // For Demo purposes, strict role checks are:
    // Finance Officer -> Approves SUBMITTED
    // Accountant -> Pays APPROVED
    // Volunteer -> Confirms DISBURSED
    
    // Simplification for demo: assume the user has permissions if they have the right 'role' string match
    // or if they are Admin (who can usually do most things for debugging)
    
    if ((role.includes('Finance') || role === 'Admin') && (item.status === CaseStatus.SUBMITTED || item.status === Status.PENDING)) {
       return (
         <button 
            onClick={(e) => { e.stopPropagation(); updateStatus(item.id, CaseStatus.APPROVED, { approvedBy: currentUser.name }); }}
            className="bg-indigo-600 text-white text-xs px-3 py-1 rounded hover:bg-indigo-700 shadow-sm flex items-center gap-1"
         >
            <ShieldCheck className="w-3 h-3" /> Approve
         </button>
       );
    }

    if ((role.includes('Accountant') || role === 'Admin') && item.status === CaseStatus.APPROVED) {
       if (transactionInputId === item.id) {
         return (
           <div className="flex items-center gap-1 animate-in fade-in" onClick={e => e.stopPropagation()}>
             <input 
               type="text" 
               placeholder="Enter Tx ID / UTR" 
               className="w-24 p-1 text-xs border border-slate-300 rounded"
               value={transactionValue}
               onChange={e => setTransactionValue(e.target.value)}
               autoFocus
             />
             <button 
               onClick={() => updateStatus(item.id, CaseStatus.DISBURSED, { transactionId: transactionValue, paymentDate: new Date().toISOString().split('T')[0] })}
               disabled={!transactionValue}
               className="bg-emerald-600 text-white text-xs px-2 py-1 rounded hover:bg-emerald-700 disabled:opacity-50"
             >
               Save
             </button>
           </div>
         );
       }
       return (
         <button 
            onClick={(e) => { e.stopPropagation(); setTransactionInputId(item.id); }}
            className="bg-emerald-600 text-white text-xs px-3 py-1 rounded hover:bg-emerald-700 shadow-sm flex items-center gap-1"
         >
            <Banknote className="w-3 h-3" /> Disburse
         </button>
       );
    }

    if ((role.includes('Volunteer') || role === 'Admin' || role.includes('Program')) && item.status === CaseStatus.DISBURSED) {
       return (
         <button 
            onClick={(e) => { e.stopPropagation(); updateStatus(item.id, CaseStatus.CLOSED); }}
            className="bg-blue-600 text-white text-xs px-3 py-1 rounded hover:bg-blue-700 shadow-sm flex items-center gap-1"
         >
            <CheckCircle className="w-3 h-3" /> Confirm & Close
         </button>
       );
    }

    return <span className="text-xs text-slate-400 italic">No actions</span>;
  };

  if (isAdding) {
    return <AddCaseForm onCancel={() => setIsAdding(false)} onSubmit={handleAddSubmit} />;
  }

  return (
    <div className="space-y-6">
      {selectedBeneficiary && (
        <BeneficiaryDetails beneficiary={selectedBeneficiary} onClose={() => setSelectedBeneficiary(null)} />
      )}

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Beneficiary Workflow</h2>
          <p className="text-sm text-slate-500 mt-1">Track cases from application to disbursement.</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors shadow-sm font-medium text-sm flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> New Application
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Toolbar */}
        <div className="p-4 border-b border-slate-100 flex gap-3 bg-slate-50/50">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by name or location..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
          </div>
          <button className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 flex items-center gap-2 text-sm font-medium">
            <Filter className="w-4 h-4" /> Status Filter
          </button>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-600 font-medium border-b border-slate-200">
              <tr>
                <th className="px-6 py-4">Applicant / Priority</th>
                <th className="px-6 py-4">Case Type</th>
                <th className="px-6 py-4">Status (Workflow)</th>
                <th className="px-6 py-4">Payment Plan</th>
                <th className="px-6 py-4 text-right">Requested</th>
                <th className="px-6 py-4 text-center">Workflow Actions</th>
                <th className="px-6 py-4 w-10"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredData.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/80 transition-colors cursor-pointer" onClick={() => setSelectedBeneficiary(item)}>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                       <div className="font-medium text-slate-900">{item.name}</div>
                       {getPriorityBadge(item.priority)}
                    </div>
                    <div className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                       <MapPin className="w-3 h-3" /> {item.location}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-slate-700 font-medium block">{item.caseType}</span>
                    <span className="text-xs text-slate-400">Sub: {item.subCategory || 'General'}</span>
                  </td>
                  <td className="px-6 py-4">
                    {getStatusBadge(item.status)}
                  </td>
                  <td className="px-6 py-4">
                     <div className="text-xs font-medium text-slate-700">{item.paymentType}</div>
                     {item.paymentType === 'Recurring' && item.recurringEndDate && (
                        <div className="text-[10px] text-slate-500 mt-0.5">Till: {item.recurringEndDate}</div>
                     )}
                     {item.transactionId && (
                        <div className="text-[10px] font-mono text-emerald-600 mt-0.5">Tx: {item.transactionId}</div>
                     )}
                  </td>
                  <td className="px-6 py-4 text-right font-medium text-slate-700">
                     ₹{item.financials?.requestedAmount?.toLocaleString() || '0'}
                  </td>
                  <td className="px-6 py-4 text-center">
                    {renderActions(item)}
                  </td>
                  <td className="px-6 py-4 text-center">
                     <button onClick={(e) => { e.stopPropagation(); setSelectedBeneficiary(item); }} className="text-slate-400 hover:text-blue-600">
                        <Eye className="w-4 h-4" />
                     </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};