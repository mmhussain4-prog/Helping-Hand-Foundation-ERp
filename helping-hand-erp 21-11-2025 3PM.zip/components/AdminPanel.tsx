
import React, { useState } from 'react';
import { User, InternalControl, ControlArea, AppModule, SystemSettings, RoleDefinition, UserRole } from '../types';
import { MOCK_USERS, MOCK_CONTROLS, MOCK_ROLES, MOCK_PROJECTS } from '../services/mockData';
import { Shield, Users, Save, Building, Sliders, UserCog, Plus, CheckCircle, X, AlertTriangle, BadgeCheck, Search } from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'users' | 'roles' | 'controls' | 'settings'>('users');
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [roles, setRoles] = useState<RoleDefinition[]>(MOCK_ROLES);
  const [controls, setControls] = useState<InternalControl[]>(MOCK_CONTROLS);
  
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  
  // System Settings State
  const [settings, setSettings] = useState<SystemSettings>({
    orgName: 'Helping Hand Foundation',
    fiscalYear: 'April - March',
    enableAiAssistant: true,
    maintenanceMode: false,
    allowVolunteerSignups: true
  });

  // Form State for New User
  const [newUser, setNewUser] = useState<Partial<User>>({
    name: '', email: '', role: 'Volunteer', department: '', assignedProjects: [], 
    accessibleModules: ['dashboard'], 
    permissions: {
      canCreateUsers: false, canApproveBudget: false, canSignCheques: false,
      canAccessFCRA: false, canViewPayroll: false, canApproveVendors: false, canVerifyStock: false
    }
  });

  // Form State for New Role
  const [newRole, setNewRole] = useState<Partial<RoleDefinition>>({
    name: '', description: '', accessibleModules: [],
    permissions: {
      canCreateUsers: false, canApproveBudget: false, canSignCheques: false,
      canAccessFCRA: false, canViewPayroll: false, canApproveVendors: false, canVerifyStock: false
    }
  });

  const MODULE_OPTIONS: AppModule[] = ['dashboard', 'beneficiaries', 'projects', 'finance', 'inventory', 'admin'];

  // --- Handlers ---
  const toggleControlStatus = (id: string) => {
    setControls(controls.map(c => {
      if (c.id === id) {
        const nextStatus = c.status === 'Compliant' ? 'Flagged' : c.status === 'Flagged' ? 'Pending' : 'Compliant';
        return { ...c, status: nextStatus };
      }
      return c;
    }));
  };

  const handleAddUser = () => {
    if (!newUser.name || !newUser.email) return;
    const user: User = {
      id: `U${Math.floor(Math.random() * 10000)}`,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role || 'Volunteer',
      department: newUser.department || 'General',
      assignedProjects: newUser.assignedProjects?.length ? newUser.assignedProjects : ['All'],
      accessibleModules: newUser.accessibleModules?.length ? newUser.accessibleModules : ['dashboard'],
      status: 'Active',
      permissions: newUser.permissions as any
    };
    setUsers([...users, user]);
    setIsUserModalOpen(false);
    // Reset form
    setNewUser({ 
      name: '', email: '', role: 'Volunteer', department: '', assignedProjects: [], accessibleModules: ['dashboard'], 
      permissions: { canCreateUsers: false, canApproveBudget: false, canSignCheques: false, canAccessFCRA: false, canViewPayroll: false, canApproveVendors: false, canVerifyStock: false }
    });
  };

  const handleAddRole = () => {
    if (!newRole.name) return;
    const role: RoleDefinition = {
      id: `R${Math.floor(Math.random() * 10000)}`,
      name: newRole.name,
      description: newRole.description || '',
      accessibleModules: newRole.accessibleModules || [],
      permissions: newRole.permissions as any
    };
    setRoles([...roles, role]);
    setIsRoleModalOpen(false);
  };

  const handleProjectToggle = (projectId: string) => {
    const current = newUser.assignedProjects || [];
    if (current.includes(projectId)) {
      setNewUser({ ...newUser, assignedProjects: current.filter(id => id !== projectId) });
    } else {
      setNewUser({ ...newUser, assignedProjects: [...current, projectId] });
    }
  };

  const handleModuleToggle = (target: 'user' | 'role', module: AppModule) => {
    if (target === 'user') {
      const current = newUser.accessibleModules || [];
      if (current.includes(module)) {
        setNewUser({ ...newUser, accessibleModules: current.filter(m => m !== module) });
      } else {
        setNewUser({ ...newUser, accessibleModules: [...current, module] });
      }
    } else {
      const current = newRole.accessibleModules || [];
      if (current.includes(module)) {
        setNewRole({ ...newRole, accessibleModules: current.filter(m => m !== module) });
      } else {
        setNewRole({ ...newRole, accessibleModules: [...current, module] });
      }
    }
  };

  const handlePermissionToggle = (target: 'user' | 'role', key: keyof User['permissions']) => {
    if (target === 'user') {
      if (!newUser.permissions) return;
      setNewUser({
        ...newUser,
        permissions: { ...newUser.permissions, [key]: !newUser.permissions[key] }
      });
    } else {
      if (!newRole.permissions) return;
      setNewRole({
        ...newRole,
        permissions: { ...newRole.permissions, [key]: !newRole.permissions[key] }
      });
    }
  };

  const handleRoleSelectForUser = (roleName: string) => {
    const selectedRole = roles.find(r => r.name === roleName);
    // Pre-fill permissions based on selected role template
    if (selectedRole) {
      setNewUser({
        ...newUser,
        role: roleName,
        accessibleModules: selectedRole.accessibleModules,
        permissions: { ...selectedRole.permissions }
      });
    } else {
      setNewUser({ ...newUser, role: roleName });
    }
  };

  // --- Renderers ---

  const UserManagement = () => (
      <div className="space-y-6 animate-in fade-in duration-300">
        <div className="flex justify-between items-center">
          <div>
             <h3 className="text-lg font-bold text-slate-800">Staff & Access Control</h3>
             <p className="text-slate-500 text-sm">Create logins and assign granular permissions per program.</p>
          </div>
          <button onClick={() => setIsUserModalOpen(true)} className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 shadow-sm">
             <Plus className="w-4 h-4" /> Create Login
          </button>
        </div>
  
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
           <table className="w-full text-sm text-left">
              <thead className="bg-slate-50 text-slate-600 font-medium border-b border-slate-200">
                 <tr>
                   <th className="px-6 py-4">User / Email</th>
                   <th className="px-6 py-4">Role & Dept</th>
                   <th className="px-6 py-4">Dashboard Access</th>
                   <th className="px-6 py-4">Key Permissions</th>
                   <th className="px-6 py-4">Projects</th>
                   <th className="px-6 py-4">Status</th>
                 </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                 {users.map(u => (
                   <tr key={u.id} className="hover:bg-slate-50">
                      <td className="px-6 py-4">
                         <div className="font-bold text-slate-800">{u.name}</div>
                         <div className="text-xs text-slate-400">{u.email}</div>
                      </td>
                      <td className="px-6 py-4">
                         <span className="inline-block bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs font-medium mb-1">
                           {u.role}
                         </span>
                         <div className="text-xs text-slate-500">{u.department}</div>
                      </td>
                      <td className="px-6 py-4">
                         <div className="flex flex-wrap gap-1 max-w-[200px]">
                             {((u.accessibleModules as AppModule[]) || []).map(mod => (
                               <span key={mod} className="bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded text-[10px] border border-slate-200 capitalize">{mod}</span>
                             ))}
                         </div>
                      </td>
                      <td className="px-6 py-4">
                         <div className="grid grid-cols-2 gap-1">
                            {u.permissions.canSignCheques && <span className="text-[10px] text-red-600 bg-red-50 px-1 rounded border border-red-100 w-fit">Signatory</span>}
                            {u.permissions.canAccessFCRA && <span className="text-[10px] text-purple-600 bg-purple-50 px-1 rounded border border-purple-100 w-fit">FCRA</span>}
                            {u.permissions.canApproveBudget && <span className="text-[10px] text-emerald-600 bg-emerald-50 px-1 rounded border border-emerald-100 w-fit">Budgets</span>}
                         </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-xs text-slate-600">
                          {(u.assignedProjects as string[]).includes('All') ? 'All Projects' : `${(u.assignedProjects as string[]).length} Assigned`}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                         <span className={`px-2 py-1 rounded-full text-xs font-bold ${u.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                           {u.status}
                         </span>
                      </td>
                   </tr>
                 ))}
              </tbody>
           </table>
        </div>
      </div>
  );

  const RoleManagement = () => (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex justify-between items-center">
        <div>
           <h3 className="text-lg font-bold text-slate-800">Role Definitions</h3>
           <p className="text-slate-500 text-sm">Define standard sets of permissions and modules for staff roles.</p>
        </div>
        <button onClick={() => setIsRoleModalOpen(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700 shadow-sm">
           <UserCog className="w-4 h-4" /> Define New Role
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {roles.map(role => (
          <div key={role.id} className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="p-4 border-b border-slate-100 flex justify-between items-start">
              <div>
                <h4 className="font-bold text-slate-800 text-lg">{role.name}</h4>
                <p className="text-sm text-slate-500 mt-1">{role.description}</p>
              </div>
              <div className="bg-slate-100 text-slate-600 text-xs px-2 py-1 rounded font-mono">{role.id}</div>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <h5 className="text-xs font-bold text-slate-400 uppercase mb-2">Accessible Modules</h5>
                <div className="flex flex-wrap gap-2">
                  {(role.accessibleModules || []).map(mod => (
                    <span key={mod} className="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs border border-blue-100 capitalize">
                      {mod}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h5 className="text-xs font-bold text-slate-400 uppercase mb-2">Critical Permissions</h5>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(role.permissions).map(([key, val]) => val && (
                    <div key={key} className="flex items-center gap-1.5 text-xs text-slate-700">
                       <CheckCircle className="w-3 h-3 text-emerald-500" />
                       {key.replace(/can/g, '').replace(/([A-Z])/g, ' $1').trim()}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const ControlsDashboard = () => {
    const grouped = controls.reduce((acc, curr) => {
       acc[curr.area] = [...(acc[curr.area] || []), curr];
       return acc;
    }, {} as Record<ControlArea, InternalControl[]>);

    return (
       <div className="space-y-6 animate-in fade-in duration-300">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
             <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                <h4 className="text-slate-500 text-xs font-bold uppercase">Total Controls</h4>
                <div className="text-2xl font-bold text-slate-800 mt-1">{controls.length}</div>
             </div>
             <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                <h4 className="text-slate-500 text-xs font-bold uppercase">Compliant</h4>
                <div className="text-2xl font-bold text-emerald-600 mt-1">
                  {controls.filter(c => c.status === 'Compliant').length}
                </div>
             </div>
             <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                <h4 className="text-slate-500 text-xs font-bold uppercase">Issues Flagged</h4>
                <div className="text-2xl font-bold text-red-600 mt-1">
                  {controls.filter(c => c.status === 'Flagged').length}
                </div>
             </div>
          </div>

          <div className="space-y-6">
             {Object.entries(grouped).map(([area, items]) => (
                <div key={area} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                   <div className="bg-slate-50 px-6 py-3 border-b border-slate-200">
                      <h3 className="font-bold text-slate-800">{area}</h3>
                   </div>
                   <div className="p-0">
                      {items.map((control, idx) => (
                         <div key={control.id} className={`px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ${idx !== items.length - 1 ? 'border-b border-slate-100' : ''}`}>
                            <div className="flex-1">
                               <div className="flex items-center gap-2 mb-1">
                                  <span className="font-mono text-xs text-slate-400 bg-slate-100 px-1 rounded">{control.id}</span>
                                  <h4 className="font-medium text-slate-800">{control.risk}</h4>
                               </div>
                               <p className="text-sm text-slate-600">{control.controlActivity}</p>
                               <div className="flex gap-4 mt-2 text-xs text-slate-500">
                                  <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {control.owner}</span>
                                  <span className="flex items-center gap-1"><Search className="w-3 h-3" /> {control.testingMethod}</span>
                               </div>
                            </div>
                            <div className="flex items-center gap-3">
                               <span className={`px-3 py-1 rounded-full text-xs font-bold border ${
                                  control.status === 'Compliant' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                                  control.status === 'Flagged' ? 'bg-red-50 text-red-700 border-red-200' :
                                  'bg-amber-50 text-amber-700 border-amber-200'
                               }`}>
                                  {control.status}
                               </span>
                               <button onClick={() => toggleControlStatus(control.id)} className="text-xs underline text-blue-600 hover:text-blue-800">
                                  Toggle Status
                               </button>
                            </div>
                         </div>
                      ))}
                   </div>
                </div>
             ))}
          </div>
       </div>
    );
  };

  const SettingsPanel = () => (
    <div className="max-w-4xl space-y-8 animate-in fade-in duration-300">
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
          <Building className="w-5 h-5 text-blue-600" /> Organization Profile
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Organization Name</label>
            <input 
              type="text" 
              value={settings.orgName} 
              onChange={(e) => setSettings({...settings, orgName: e.target.value})}
              className="w-full p-2 border border-slate-200 rounded-lg" 
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Fiscal Year Cycle</label>
            <select 
              value={settings.fiscalYear} 
              onChange={(e) => setSettings({...settings, fiscalYear: e.target.value})}
              className="w-full p-2 border border-slate-200 rounded-lg bg-white"
            >
              <option value="April - March">April - March (India)</option>
              <option value="Jan - Dec">Jan - Dec (Global)</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
          <Sliders className="w-5 h-5 text-blue-600" /> Feature Flags & System Switches
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-200">
            <div>
              <h4 className="font-medium text-slate-800">AI Assistant (Gemini)</h4>
              <p className="text-xs text-slate-500">Enable generative AI features for staff.</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" checked={settings.enableAiAssistant} onChange={e => setSettings({...settings, enableAiAssistant: e.target.checked})} />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-200">
            <div>
              <h4 className="font-medium text-slate-800">Maintenance Mode</h4>
              <p className="text-xs text-slate-500">Restrict access for all non-admin users.</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" checked={settings.maintenanceMode} onChange={e => setSettings({...settings, maintenanceMode: e.target.checked})} />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-red-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600"></div>
            </label>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
         <button className="bg-slate-800 text-white px-6 py-2 rounded-lg font-medium flex items-center gap-2 hover:bg-slate-700">
           <Save className="w-4 h-4" /> Save Configuration
         </button>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Modals */}
      {isUserModalOpen && (
         <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl overflow-hidden flex flex-col max-h-[90vh]">
               <div className="bg-slate-800 p-4 flex justify-between items-center text-white shrink-0">
                  <h3 className="font-bold text-lg flex items-center gap-2"><UserCog className="w-5 h-5" /> Create New User Login</h3>
                  <button onClick={() => setIsUserModalOpen(false)} className="hover:bg-slate-700 p-1 rounded"><X className="w-5 h-5" /></button>
               </div>
               <div className="p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Left Col: Basic Info */}
                  <div className="space-y-4">
                     <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                        <input type="text" className="w-full p-2 border border-slate-200 rounded-lg" value={newUser.name} onChange={e => setNewUser({...newUser, name: e.target.value})} placeholder="e.g. John Doe" />
                     </div>
                     <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                        <input type="email" className="w-full p-2 border border-slate-200 rounded-lg" value={newUser.email} onChange={e => setNewUser({...newUser, email: e.target.value})} placeholder="user@hhf.org" />
                     </div>
                     <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Role (Template)</label>
                        <select 
                           className="w-full p-2 border border-slate-200 rounded-lg"
                           value={newUser.role}
                           onChange={e => handleRoleSelectForUser(e.target.value)}
                        >
                           <option value="">Select Role...</option>
                           {Object.values(UserRole).map(r => <option key={r} value={r}>{r}</option>)}
                           {roles.map(r => !Object.values(UserRole).includes(r.name as any) && <option key={r.id} value={r.name}>{r.name}</option>)}
                        </select>
                     </div>
                     <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Department</label>
                        <input type="text" className="w-full p-2 border border-slate-200 rounded-lg" value={newUser.department} onChange={e => setNewUser({...newUser, department: e.target.value})} placeholder="e.g. Finance" />
                     </div>
                  </div>

                  {/* Right Col: Permissions */}
                  <div className="space-y-4">
                     <div>
                        <label className="block text-sm font-bold text-slate-700 mb-2">Accessible Modules</label>
                        <div className="flex flex-wrap gap-2">
                           {MODULE_OPTIONS.map(m => (
                              <button 
                                 key={m}
                                 onClick={() => handleModuleToggle('user', m)}
                                 className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${
                                    newUser.accessibleModules?.includes(m) 
                                    ? 'bg-blue-600 text-white border-blue-600' 
                                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:border-blue-300'
                                 }`}
                              >
                                 {m.charAt(0).toUpperCase() + m.slice(1)}
                              </button>
                           ))}
                        </div>
                     </div>

                     <div>
                        <label className="block text-sm font-bold text-slate-700 mb-2">Assigned Projects (Program Scope)</label>
                        <div className="max-h-32 overflow-y-auto border border-slate-200 rounded-lg p-2 space-y-1">
                           <label className="flex items-center gap-2 text-sm p-1 hover:bg-slate-50 rounded cursor-pointer">
                              <input 
                                 type="checkbox" 
                                 checked={newUser.assignedProjects?.includes('All')} 
                                 onChange={() => handleProjectToggle('All')}
                                 className="rounded text-blue-600"
                              />
                              <span className="font-bold text-slate-700">All Projects</span>
                           </label>
                           {MOCK_PROJECTS.map(p => (
                              <label key={p.id} className="flex items-center gap-2 text-sm p-1 hover:bg-slate-50 rounded cursor-pointer">
                                 <input 
                                    type="checkbox" 
                                    checked={newUser.assignedProjects?.includes(p.id)} 
                                    onChange={() => handleProjectToggle(p.id)}
                                    disabled={newUser.assignedProjects?.includes('All')}
                                    className="rounded text-blue-600 disabled:opacity-50"
                                 />
                                 <span className="text-slate-600">{p.name}</span>
                              </label>
                           ))}
                        </div>
                     </div>

                     <div>
                        <label className="block text-sm font-bold text-slate-700 mb-2">Granular Permissions</label>
                        <div className="grid grid-cols-2 gap-2">
                           {Object.keys(newUser.permissions || {}).map(key => (
                              <label key={key} className="flex items-center gap-2 text-xs cursor-pointer p-1 hover:bg-slate-50 rounded">
                                 <input 
                                    type="checkbox" 
                                    checked={(newUser.permissions as any)[key]} 
                                    onChange={() => handlePermissionToggle('user', key as keyof User['permissions'])}
                                    className="rounded text-emerald-600"
                                 />
                                 <span className="text-slate-700">{key.replace(/can/g, '').replace(/([A-Z])/g, ' $1').trim()}</span>
                              </label>
                           ))}
                        </div>
                     </div>
                  </div>
               </div>
               <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-3">
                  <button onClick={() => setIsUserModalOpen(false)} className="px-4 py-2 border border-slate-300 rounded-lg text-slate-600 hover:bg-slate-100">Cancel</button>
                  <button onClick={handleAddUser} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 shadow-sm">Create User</button>
               </div>
            </div>
         </div>
      )}

      {isRoleModalOpen && (
         <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden">
               <div className="bg-indigo-800 p-4 flex justify-between items-center text-white">
                  <h3 className="font-bold text-lg flex items-center gap-2"><BadgeCheck className="w-5 h-5" /> Define New Role</h3>
                  <button onClick={() => setIsRoleModalOpen(false)} className="hover:bg-indigo-700 p-1 rounded"><X className="w-5 h-5" /></button>
               </div>
               <div className="p-6 space-y-4">
                  <div>
                     <label className="block text-sm font-medium text-slate-700 mb-1">Role Name</label>
                     <input type="text" className="w-full p-2 border border-slate-200 rounded-lg" value={newRole.name} onChange={e => setNewRole({...newRole, name: e.target.value})} placeholder="e.g. Field Coordinator" />
                  </div>
                  <div>
                     <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
                     <textarea className="w-full p-2 border border-slate-200 rounded-lg h-20" value={newRole.description} onChange={e => setNewRole({...newRole, description: e.target.value})} placeholder="Describe the responsibilities..." />
                  </div>
                  <div>
                     <label className="block text-sm font-bold text-slate-700 mb-2">Default Modules</label>
                     <div className="flex flex-wrap gap-2">
                        {MODULE_OPTIONS.map(m => (
                           <button 
                              key={m}
                              onClick={() => handleModuleToggle('role', m)}
                              className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${
                                 newRole.accessibleModules?.includes(m) 
                                 ? 'bg-indigo-600 text-white border-indigo-600' 
                                 : 'bg-slate-50 text-slate-600 border-slate-200 hover:border-indigo-300'
                              }`}
                           >
                              {m.charAt(0).toUpperCase() + m.slice(1)}
                           </button>
                        ))}
                     </div>
                  </div>
               </div>
               <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-3">
                  <button onClick={() => setIsRoleModalOpen(false)} className="px-4 py-2 border border-slate-300 rounded-lg text-slate-600 hover:bg-slate-100">Cancel</button>
                  <button onClick={handleAddRole} className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 shadow-sm">Save Role</button>
               </div>
            </div>
         </div>
      )}

      {/* Tabs */}
      <div className="flex space-x-4 border-b border-slate-200">
        <button 
          onClick={() => setActiveTab('users')} 
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors ${activeTab === 'users' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
        >
          User Management
        </button>
        <button 
          onClick={() => setActiveTab('roles')} 
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors ${activeTab === 'roles' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
        >
          Roles & Permissions
        </button>
        <button 
          onClick={() => setActiveTab('controls')} 
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors ${activeTab === 'controls' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
        >
          Internal Controls
        </button>
        <button 
          onClick={() => setActiveTab('settings')} 
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors ${activeTab === 'settings' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
        >
          System Settings
        </button>
      </div>

      <div className="min-h-[400px]">
        {activeTab === 'users' && <UserManagement />}
        {activeTab === 'roles' && <RoleManagement />}
        {activeTab === 'controls' && <ControlsDashboard />}
        {activeTab === 'settings' && <SettingsPanel />}
      </div>
    </div>
  );
};
