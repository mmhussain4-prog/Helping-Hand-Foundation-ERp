
import React from 'react';
import { Beneficiary } from '../types';
import { X, MapPin, Phone, Home, Zap, Users, Wallet, FileText, AlertTriangle } from 'lucide-react';

interface BeneficiaryDetailsProps {
  beneficiary: Beneficiary;
  onClose: () => void;
}

export const BeneficiaryDetails: React.FC<BeneficiaryDetailsProps> = ({ beneficiary, onClose }) => {
  const { familyMembers = [], incomeSources = [], monthlyExpenses = [], financials } = beneficiary;

  const totalIncome = incomeSources.reduce((acc, i) => acc + i.amount, 0) + familyMembers.reduce((acc, m) => acc + (m.earnings || 0), 0);
  const totalExpense = monthlyExpenses.reduce((acc, i) => acc + i.amount, 0);
  const net = totalIncome - totalExpense;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/20 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-2xl bg-white h-full shadow-2xl overflow-y-auto animate-in slide-in-from-right duration-300" onClick={e => e.stopPropagation()}>
        
        {/* Header */}
        <div className="bg-slate-800 text-white p-6 sticky top-0 z-10">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h2 className="text-2xl font-bold">{beneficiary.name}</h2>
              <p className="text-slate-400 text-sm flex items-center gap-2 mt-1">
                <span className="bg-slate-700 px-2 py-0.5 rounded text-xs">{beneficiary.id}</span>
                <MapPin className="w-3 h-3" /> {beneficiary.location}
              </p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-slate-700 rounded-full transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-slate-700/50">
             <div>
               <div className="text-xs text-slate-400 uppercase font-bold">Case Type</div>
               <div className="font-medium text-blue-200">{beneficiary.caseType}</div>
             </div>
             <div>
               <div className="text-xs text-slate-400 uppercase font-bold">Contact</div>
               <div className="font-medium flex items-center gap-1"><Phone className="w-3 h-3" /> {beneficiary.contact}</div>
             </div>
             <div>
               <div className="text-xs text-slate-400 uppercase font-bold">Status</div>
               <div className="font-medium text-emerald-400">{beneficiary.status}</div>
             </div>
          </div>
        </div>

        <div className="p-6 space-y-8">
          
          {/* Coordinator Recommendation */}
          {beneficiary.coordinatorRecommendation && (
            <div className="bg-amber-50 border border-amber-100 rounded-lg p-4">
              <h3 className="text-sm font-bold text-amber-800 mb-2 flex items-center gap-2">
                <FileText className="w-4 h-4" /> Coordinator's Note
              </h3>
              <p className="text-sm text-amber-900 italic">"{beneficiary.coordinatorRecommendation}"</p>
            </div>
          )}

          {/* Socio-Economic Snapshot */}
          <div>
             <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
               <Home className="w-5 h-5 text-blue-600" /> Household & Housing
             </h3>
             <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                <div>
                   <div className="text-xs text-slate-500">Housing Status</div>
                   <div className="font-semibold text-slate-800">{beneficiary.housingStatus || 'N/A'}</div>
                </div>
                {beneficiary.housingStatus === 'Rent' && (
                  <div>
                     <div className="text-xs text-slate-500">Monthly Rent</div>
                     <div className="font-semibold text-slate-800">₹{beneficiary.rentAmount || 0}</div>
                  </div>
                )}
                <div>
                   <div className="text-xs text-slate-500 flex items-center gap-1"><Zap className="w-3 h-3" /> Electric Bill</div>
                   <div className="font-semibold text-slate-800">₹{beneficiary.electricityBill || 0}</div>
                </div>
             </div>
          </div>

          {/* Family Members */}
          <div>
             <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
               <Users className="w-5 h-5 text-blue-600" /> Family Demographics
             </h3>
             <div className="overflow-hidden border border-slate-200 rounded-xl">
               <table className="w-full text-sm text-left">
                 <thead className="bg-slate-50 text-slate-600 font-medium">
                   <tr>
                     <th className="px-4 py-3">Name</th>
                     <th className="px-4 py-3">Relation</th>
                     <th className="px-4 py-3">Age/Gender</th>
                     <th className="px-4 py-3">Education/Job</th>
                     <th className="px-4 py-3 text-right">Income</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100">
                   {familyMembers.length > 0 ? familyMembers.map((m, i) => (
                     <tr key={i} className="hover:bg-slate-50/50">
                       <td className="px-4 py-3 font-medium text-slate-800">{m.name}</td>
                       <td className="px-4 py-3 text-slate-500">{m.relation}</td>
                       <td className="px-4 py-3 text-slate-500">{m.age} / {m.gender.charAt(0)}</td>
                       <td className="px-4 py-3">
                         <div className="text-slate-800">{m.education}</div>
                         {m.occupation && <div className="text-xs text-slate-400">{m.occupation}</div>}
                       </td>
                       <td className="px-4 py-3 text-right text-emerald-600 font-medium">₹{m.earnings}</td>
                     </tr>
                   )) : (
                     <tr><td colSpan={5} className="px-4 py-6 text-center text-slate-400">No detailed family records found.</td></tr>
                   )}
                 </tbody>
               </table>
             </div>
          </div>

          {/* Financial Profile */}
          <div>
             <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
               <Wallet className="w-5 h-5 text-blue-600" /> Financial Analysis
             </h3>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
               <div className="border border-slate-200 rounded-xl p-4">
                 <h4 className="text-sm font-bold text-emerald-700 mb-3 border-b border-slate-100 pb-2">Income Sources</h4>
                 <ul className="space-y-2 text-sm">
                    {familyMembers.filter(m => m.earnings > 0).map((m, i) => (
                      <li key={`fam-${i}`} className="flex justify-between">
                        <span className="text-slate-600">{m.name} (Salary)</span>
                        <span className="font-medium">₹{m.earnings}</span>
                      </li>
                    ))}
                    {incomeSources.map((inc, i) => (
                      <li key={`inc-${i}`} className="flex justify-between">
                        <span className="text-slate-600">{inc.label}</span>
                        <span className="font-medium">₹{inc.amount}</span>
                      </li>
                    ))}
                    <li className="flex justify-between pt-2 border-t border-slate-100 font-bold text-emerald-600">
                      <span>Total Income</span>
                      <span>₹{totalIncome}</span>
                    </li>
                 </ul>
               </div>

               <div className="border border-slate-200 rounded-xl p-4">
                 <h4 className="text-sm font-bold text-red-700 mb-3 border-b border-slate-100 pb-2">Monthly Expenses</h4>
                 <ul className="space-y-2 text-sm">
                    {monthlyExpenses.map((exp, i) => (
                      <li key={i} className="flex justify-between">
                        <span className="text-slate-600">{exp.label}</span>
                        <span className="font-medium">₹{exp.amount}</span>
                      </li>
                    ))}
                    <li className="flex justify-between pt-2 border-t border-slate-100 font-bold text-red-600">
                      <span>Total Expenses</span>
                      <span>₹{totalExpense}</span>
                    </li>
                 </ul>
               </div>
             </div>

             {/* Assets & Net */}
             <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                <div className="flex justify-between items-center mb-4">
                  <span className="font-medium text-slate-600">Net Monthly Balance</span>
                  <span className={`text-xl font-bold ${net < 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                    ₹{net}
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                   <div className="bg-white p-3 rounded border border-slate-200">
                     <div className="text-xs font-bold text-slate-400 uppercase mb-1">Reported Assets</div>
                     <div className="text-slate-800">{beneficiary.assets || 'None declared'}</div>
                   </div>
                   <div className="bg-white p-3 rounded border border-slate-200">
                     <div className="text-xs font-bold text-slate-400 uppercase mb-1">Liabilities / Debts</div>
                     <div className="text-slate-800">{beneficiary.liabilities || 'None declared'}</div>
                   </div>
                </div>
             </div>
          </div>

          {/* Grant Request */}
          {financials && (
            <div>
              <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                 <AlertTriangle className="w-5 h-5 text-blue-600" /> Grant Request Details
              </h3>
              <div className="bg-blue-50 border border-blue-100 rounded-xl p-5">
                 <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-center">
                    <div>
                      <div className="text-xs text-blue-500 uppercase font-bold">Total Cost</div>
                      <div className="text-lg font-bold text-slate-800">₹{financials.totalCost}</div>
                    </div>
                    <div>
                      <div className="text-xs text-blue-500 uppercase font-bold">Own Contrib.</div>
                      <div className="text-lg font-bold text-slate-800">₹{financials.ownContribution}</div>
                    </div>
                    <div>
                      <div className="text-xs text-blue-500 uppercase font-bold">Other Donors</div>
                      <div className="text-lg font-bold text-slate-800">₹{financials.otherDonors}</div>
                    </div>
                    <div className="bg-white rounded-lg border border-blue-200 py-1">
                      <div className="text-xs text-blue-600 uppercase font-bold">Requested</div>
                      <div className="text-xl font-bold text-blue-700">₹{financials.requestedAmount}</div>
                    </div>
                 </div>
                 {financials.details && (
                   <div className="mt-4 pt-4 border-t border-blue-100 text-sm text-blue-900">
                     <strong>Details:</strong> {financials.details}
                   </div>
                 )}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};