
import React, { useState, useEffect } from 'react';
import { Project, Beneficiary, PaymentMode, Transaction } from '../types';
import { X, Save, Building2, Users, IndianRupee, FileText, List } from 'lucide-react';

interface FinanceEntryFormProps {
  onCancel: () => void;
  onSubmit: (data: Partial<Transaction>) => void;
  projects: Project[];
  beneficiaries: Beneficiary[];
  incomeHeads: string[];
  expenseHeads: string[];
}

export const FinanceEntryForm: React.FC<FinanceEntryFormProps> = ({ onCancel, onSubmit, projects, beneficiaries, incomeHeads, expenseHeads }) => {
  const [type, setType] = useState<'Income' | 'Expense'>('Expense');
  
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    description: '',
    category: '',
    paymentMode: 'NEFT/RTGS' as PaymentMode,
    bankReference: '',
    
    // Linking
    linkType: 'General' as 'General' | 'Project' | 'Beneficiary',
    linkedId: '',
    
    // Amounts & Tax
    grossAmount: 0,
    tdsPercent: 0,
    tdsSection: '',
    invoiceUrl: ''
  });

  const [bulkDetails, setBulkDetails] = useState('');
  // Expanded logic to capture Widow/Orphan support and explicit Bulk category
  const showBulkOption = type === 'Expense' && ['Salary', 'Widow', 'Orphan', 'Bulk'].some(k => formData.category.includes(k));

  // Derived Net Amount
  const tdsAmount = (formData.grossAmount * formData.tdsPercent) / 100;
  const netAmount = formData.grossAmount - tdsAmount;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const finalAmount = type === 'Expense' ? -netAmount : netAmount;
    const finalDescription = formData.description + (bulkDetails ? ` [Bulk Details: ${bulkDetails}]` : '');
    
    const transaction: Partial<Transaction> = {
      date: formData.date,
      type: type === 'Income' ? 'Donation' : 'Expense', // Simplifying for demo
      description: finalDescription,
      category: formData.category,
      amount: finalAmount,
      grossAmount: formData.grossAmount,
      tdsDeducted: tdsAmount,
      tdsSection: formData.tdsSection,
      paymentMode: formData.paymentMode,
      bankReference: formData.bankReference,
      reconciled: false,
      linkedProjectId: formData.linkType === 'Project' ? formData.linkedId : undefined,
      linkedBeneficiaryId: formData.linkType === 'Beneficiary' ? formData.linkedId : undefined,
    };

    onSubmit(transaction);
  };

  // Reset category when switching type
  useEffect(() => {
    setFormData(prev => ({ ...prev, category: '' }));
  }, [type]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-3xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-slate-800 p-4 flex justify-between items-center text-white shrink-0">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <IndianRupee className="w-5 h-5" /> New Financial Entry
          </h3>
          <button onClick={onCancel} className="hover:bg-slate-700 p-1 rounded transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto">
          
          {/* Toggle Type */}
          <div className="flex p-1 bg-slate-100 rounded-lg mb-6">
            <button 
              type="button" 
              onClick={() => setType('Income')}
              className={`flex-1 py-2 text-sm font-bold rounded-md transition-all ${type === 'Income' ? 'bg-emerald-600 text-white shadow' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Income / Receipt
            </button>
            <button 
              type="button" 
              onClick={() => setType('Expense')}
              className={`flex-1 py-2 text-sm font-bold rounded-md transition-all ${type === 'Expense' ? 'bg-red-600 text-white shadow' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Expense / Payment
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Section 1: Linking */}
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
              <label className="block text-xs font-bold text-slate-500 uppercase mb-3">Allocation & Context</label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                   <label className="block text-sm font-medium text-slate-700 mb-1">Linked To</label>
                   <select 
                      value={formData.linkType}
                      onChange={e => setFormData({...formData, linkType: e.target.value as any, linkedId: ''})}
                      className="w-full p-2 border border-slate-200 rounded-lg"
                   >
                     <option value="General">General / Admin</option>
                     <option value="Project">Specific Project</option>
                     <option value="Beneficiary">Specific Beneficiary</option>
                   </select>
                </div>

                {formData.linkType === 'Project' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Select Project</label>
                    <select 
                      value={formData.linkedId}
                      onChange={e => setFormData({...formData, linkedId: e.target.value})}
                      required
                      className="w-full p-2 border border-slate-200 rounded-lg"
                    >
                      <option value="">-- Select Project --</option>
                      {projects.map(p => <option key={p.id} value={p.id}>{p.name} ({p.nature})</option>)}
                    </select>
                  </div>
                )}

                {formData.linkType === 'Beneficiary' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Select Beneficiary</label>
                    <select 
                      value={formData.linkedId}
                      onChange={e => setFormData({...formData, linkedId: e.target.value})}
                      required
                      className="w-full p-2 border border-slate-200 rounded-lg"
                    >
                      <option value="">-- Select Beneficiary --</option>
                      {beneficiaries.map(b => <option key={b.id} value={b.id}>{b.name} ({b.caseType})</option>)}
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Transaction Date</label>
                  <input 
                    type="date"
                    value={formData.date}
                    onChange={e => setFormData({...formData, date: e.target.value})}
                    required
                    className="w-full p-2 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               <div className="md:col-span-2">
                 <label className="block text-sm font-medium text-slate-700 mb-1">Description / Narration</label>
                 <input 
                   type="text"
                   value={formData.description}
                   onChange={e => setFormData({...formData, description: e.target.value})}
                   required
                   placeholder="e.g. Vendor Payment for Medical Supplies"
                   className="w-full p-2 border border-slate-200 rounded-lg"
                 />
               </div>
               
               <div>
                 <label className="block text-sm font-medium text-slate-700 mb-1">Category ({type} Head)</label>
                 <input 
                   type="text"
                   value={formData.category}
                   onChange={e => setFormData({...formData, category: e.target.value})}
                   required
                   list="ledger-heads"
                   placeholder="Search or type..."
                   className="w-full p-2 border border-slate-200 rounded-lg"
                 />
                 <datalist id="ledger-heads">
                   {(type === 'Income' ? incomeHeads : expenseHeads).map(head => (
                     <option key={head} value={head} />
                   ))}
                 </datalist>
               </div>

               <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Payment Mode</label>
                  <select 
                    value={formData.paymentMode}
                    onChange={e => setFormData({...formData, paymentMode: e.target.value as PaymentMode})}
                    className="w-full p-2 border border-slate-200 rounded-lg"
                  >
                    <option value="NEFT/RTGS">NEFT/RTGS</option>
                    <option value="Cheque">Cheque</option>
                    <option value="UPI">UPI</option>
                    <option value="Cash">Cash</option>
                    <option value="Demand Draft">Demand Draft</option>
                  </select>
               </div>

               <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Bank Reference (UTR / Cheque No)</label>
                  <input 
                    type="text"
                    value={formData.bankReference}
                    onChange={e => setFormData({...formData, bankReference: e.target.value})}
                    className="w-full p-2 border border-slate-200 rounded-lg"
                    placeholder="Optional for Cash"
                  />
               </div>

               {showBulkOption && (
                  <div className="md:col-span-2 bg-yellow-50 p-3 rounded-lg border border-yellow-100 animate-in fade-in">
                     <label className="block text-sm font-bold text-yellow-800 mb-2 flex items-center gap-2">
                        <List className="w-4 h-4" /> Bulk Payment Details
                     </label>
                     <textarea 
                        value={bulkDetails}
                        onChange={(e) => setBulkDetails(e.target.value)}
                        className="w-full p-2 border border-yellow-200 rounded-lg text-sm h-24 placeholder-slate-400"
                        placeholder="Paste list of beneficiaries, account numbers, and amounts here..."
                     />
                  </div>
               )}
            </div>

            {/* Section 3: Amounts & TDS */}
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
               <label className="block text-xs font-bold text-blue-800 uppercase mb-3">Financials & Tax Compliance (TDS)</label>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Gross Amount (₹)</label>
                    <input 
                      type="number"
                      value={formData.grossAmount}
                      onChange={e => setFormData({...formData, grossAmount: parseFloat(e.target.value) || 0})}
                      className="w-full p-2 border border-slate-200 rounded-lg font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">TDS Rate (%)</label>
                    <div className="flex gap-2">
                       <input 
                         type="number"
                         value={formData.tdsPercent}
                         onChange={e => setFormData({...formData, tdsPercent: parseFloat(e.target.value) || 0})}
                         className="w-20 p-2 border border-slate-200 rounded-lg"
                       />
                       <select 
                         value={formData.tdsSection}
                         onChange={e => setFormData({...formData, tdsSection: e.target.value})}
                         className="flex-1 p-2 border border-slate-200 rounded-lg text-xs"
                       >
                         <option value="">Section</option>
                         <option value="194C">194C (Contract)</option>
                         <option value="194J">194J (Prof.)</option>
                         <option value="194I">194I (Rent)</option>
                         <option value="192">Salary</option>
                       </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Net Payable</label>
                    <div className="w-full p-2 bg-white border border-blue-200 rounded-lg text-blue-800 font-bold">
                      ₹ {netAmount.toLocaleString()}
                    </div>
                    {tdsAmount > 0 && (
                      <div className="text-[10px] text-slate-500 mt-1">TDS: ₹{tdsAmount}</div>
                    )}
                  </div>
               </div>
            </div>

            <div className="flex gap-3 pt-4 border-t border-slate-100">
              <button type="button" onClick={onCancel} className="flex-1 py-2.5 border border-slate-200 rounded-lg font-medium text-slate-600 hover:bg-slate-50">
                Cancel
              </button>
              <button type="submit" className={`flex-1 py-2.5 text-white rounded-lg font-medium shadow-sm ${type === 'Income' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-red-600 hover:bg-red-700'}`}>
                Record Entry
              </button>
            </div>

          </form>
        </div>
      </div>
    </div>
  );
};