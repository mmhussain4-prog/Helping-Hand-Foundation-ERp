
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { Project, Transaction, Beneficiary, Status, User, CaseStatus } from '../types';
import { IndianRupee, Users, Package, TrendingUp, AlertCircle, CheckCircle, FileText, ShieldCheck, Banknote, ClipboardCheck, ArrowRight } from 'lucide-react';

interface DashboardProps {
  projects: Project[];
  transactions: Transaction[];
  beneficiaries: Beneficiary[];
  currentUser: User;
}

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'];

const StatCard = ({ title, value, icon: Icon, trend, trendValue, color, subtitle }: any) => (
  <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-slate-500">{title}</p>
        <h3 className="text-2xl font-bold text-slate-800 mt-1">{value}</h3>
      </div>
      <div className={`p-3 rounded-full ${color}`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
    </div>
    {(trend || subtitle) && (
      <div className="mt-4 flex items-center text-sm">
        {trend && (
           <span className={`font-medium ${trend === 'up' ? 'text-emerald-600' : 'text-red-600'}`}>
             {trend === 'up' ? '+' : '-'}{trendValue}%
           </span>
        )}
        {subtitle && <span className="text-slate-400 ml-2">{subtitle}</span>}
      </div>
    )}
  </div>
);

export const Dashboard: React.FC<DashboardProps> = ({ projects, transactions, beneficiaries, currentUser }) => {
  
  // --- Role: Program Manager Dashboard ---
  if (currentUser.role === 'Program Manager') {
    // Filter data for assigned projects
    const assignedProjectIds = currentUser.assignedProjects;
    const myProjects = projects.filter(p => assignedProjectIds.includes(p.id) || assignedProjectIds.includes('All'));
    const myBeneficiaries = beneficiaries.filter(b => assignedProjectIds.includes(b.projectId || '') || assignedProjectIds.includes('All'));
    
    const totalBudget = myProjects.reduce((acc, p) => acc + p.approvedBudget + p.carryForward, 0);
    const totalSpent = myProjects.reduce((acc, p) => acc + p.spent, 0);
    const totalRemaining = totalBudget - totalSpent;
    const pendingBeneficiaries = myBeneficiaries.filter(b => b.status === CaseStatus.SUBMITTED).length;

    const utilizationData = myProjects.map(p => ({
      name: p.name.substring(0, 15) + '...',
      budget: p.approvedBudget + p.carryForward,
      spent: p.spent
    }));

    return (
      <div className="space-y-6 animate-in fade-in duration-500">
         <div className="bg-indigo-900 text-white p-6 rounded-xl mb-6 flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold">Welcome, {currentUser.name}</h2>
              <p className="text-indigo-200 text-sm mt-1">Program Management Dashboard • Managing {myProjects.length} Projects</p>
            </div>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatCard title="Total Portfolio Budget" value={`₹${totalBudget.toLocaleString()}`} icon={IndianRupee} color="bg-blue-500" subtitle="Approved + Carry Forward" />
            <StatCard title="Funds Utilized" value={`₹${totalSpent.toLocaleString()}`} icon={TrendingUp} color="bg-emerald-500" subtitle={`${totalBudget > 0 ? ((totalSpent/totalBudget)*100).toFixed(1) : 0}% Utilization`} />
            <StatCard title="Remaining Funds" value={`₹${totalRemaining.toLocaleString()}`} icon={Package} color="bg-amber-500" subtitle="Available for disbursal" />
            <StatCard title="Pending Beneficiaries" value={pendingBeneficiaries} icon={Users} color="bg-indigo-500" subtitle="Awaiting Finance Approval" />
         </div>

         <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
               <h3 className="font-bold text-slate-800 mb-6">Budget Utilization per Project</h3>
               <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                     <BarChart data={utilizationData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" style={{ fontSize: '12px' }} />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="budget" fill="#3b82f6" name="Total Budget" />
                        <Bar dataKey="spent" fill="#10b981" name="Spent" />
                     </BarChart>
                  </ResponsiveContainer>
               </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
               <h3 className="font-bold text-slate-800 mb-4">Your Projects Status</h3>
               <div className="space-y-4">
                  {myProjects.map(p => {
                    const total = p.approvedBudget + p.carryForward;
                    const pct = total > 0 ? Math.min(100, (p.spent / total) * 100) : 0;
                    return (
                      <div key={p.id}>
                        <div className="flex justify-between text-sm mb-1">
                           <span className="font-medium text-slate-700">{p.name}</span>
                           <span className="text-slate-500">{pct.toFixed(0)}% Spent</span>
                        </div>
                        <div className="w-full bg-slate-100 h-2 rounded-full">
                           <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${pct}%` }}></div>
                        </div>
                      </div>
                    );
                  })}
               </div>
            </div>
         </div>
      </div>
    );
  }

  // --- Role: Accountant Dashboard ---
  if (currentUser.role === 'Accountant') {
    const readyToDisburse = beneficiaries.filter(b => b.status === CaseStatus.APPROVED);
    const recentlyDisbursed = beneficiaries.filter(b => b.status === CaseStatus.DISBURSED).length;
    const projectsManaged = projects.length;
    const pendingExpenses = transactions.filter(t => t.type === 'Expense' && !t.reconciled).length;

    return (
      <div className="space-y-6 animate-in fade-in duration-500">
         <div className="bg-emerald-900 text-white p-6 rounded-xl mb-6 flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold">Accountant Dashboard</h2>
              <p className="text-emerald-200 text-sm mt-1">Disbursements, Project Budgets & Bookkeeping</p>
            </div>
            <div className="text-right">
               <div className="text-2xl font-bold">{readyToDisburse.length}</div>
               <div className="text-xs text-emerald-200">Pending Payouts</div>
            </div>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatCard title="Ready to Pay" value={readyToDisburse.length} icon={Banknote} color="bg-emerald-600" subtitle="Approved Beneficiaries" />
            <StatCard title="Active Projects" value={projectsManaged} icon={ClipboardCheck} color="bg-blue-600" subtitle="Budget Tracking" />
            <StatCard title="Disbursed (Month)" value={recentlyDisbursed} icon={CheckCircle} color="bg-amber-500" subtitle="Successfully Paid" />
            <StatCard title="Unreconciled Tx" value={pendingExpenses} icon={FileText} color="bg-indigo-500" subtitle="Expenses Pending Check" />
         </div>

         <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Disbursement Queue */}
            <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-100">
               <div className="flex justify-between items-center mb-4">
                  <h3 className="font-bold text-slate-800 flex items-center gap-2">
                     <Banknote className="w-5 h-5 text-emerald-600" /> Disbursement Queue
                  </h3>
                  <span className="bg-emerald-100 text-emerald-800 text-xs px-2 py-1 rounded-full font-bold">Priority Action</span>
               </div>
               <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                     <thead className="bg-slate-50 text-slate-600">
                        <tr>
                           <th className="px-4 py-2">Beneficiary</th>
                           <th className="px-4 py-2">Case Type</th>
                           <th className="px-4 py-2">Approved By</th>
                           <th className="px-4 py-2 text-right">Amount</th>
                           <th className="px-4 py-2 text-center">Action</th>
                        </tr>
                     </thead>
                     <tbody className="divide-y divide-slate-100">
                        {readyToDisburse.length === 0 && (
                           <tr><td colSpan={5} className="p-6 text-center text-slate-400">No approved cases pending payment.</td></tr>
                        )}
                        {readyToDisburse.map(b => (
                           <tr key={b.id} className="hover:bg-slate-50">
                              <td className="px-4 py-3 font-medium">{b.name}</td>
                              <td className="px-4 py-3">{b.caseType}</td>
                              <td className="px-4 py-3 text-slate-500">{b.approvedBy || 'Finance'}</td>
                              <td className="px-4 py-3 text-right font-bold text-emerald-700">₹{b.financials?.requestedAmount.toLocaleString()}</td>
                              <td className="px-4 py-3 text-center">
                                 <span className="text-xs bg-emerald-50 text-emerald-600 px-2 py-1 rounded border border-emerald-100 font-medium">Ready to Pay</span>
                              </td>
                           </tr>
                        ))}
                     </tbody>
                  </table>
               </div>
            </div>

            {/* Project Budget Snapshot */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
               <h3 className="font-bold text-slate-800 mb-4">Project Budget Overview</h3>
               <div className="space-y-4 max-h-80 overflow-y-auto pr-2">
                  {projects.map(p => {
                     const total = p.approvedBudget + p.carryForward;
                     const pct = total > 0 ? (p.spent / total) * 100 : 0;
                     return (
                        <div key={p.id}>
                           <div className="flex justify-between text-xs mb-1">
                              <span className="font-semibold text-slate-700">{p.name}</span>
                              <span className={pct > 90 ? 'text-red-600' : 'text-slate-500'}>{pct.toFixed(0)}%</span>
                           </div>
                           <div className="w-full bg-slate-100 h-1.5 rounded-full">
                              <div className={`h-1.5 rounded-full ${pct > 90 ? 'bg-red-500' : 'bg-blue-500'}`} style={{ width: `${Math.min(100, pct)}%` }}></div>
                           </div>
                        </div>
                     );
                  })}
               </div>
            </div>
         </div>
      </div>
    );
  }

  // --- Role: Finance Officer Dashboard ---
  if (currentUser.role === 'Finance Officer' || currentUser.role === 'Finance Controller') {
    const totalFunds = transactions.reduce((acc, t) => t.type !== 'Expense' ? acc + t.amount : acc, 0);
    const totalExpenses = transactions.reduce((acc, t) => t.type === 'Expense' ? acc + Math.abs(t.amount) : acc, 0);
    const pendingApprovals = beneficiaries.filter(b => b.status === CaseStatus.SUBMITTED).length;
    const pendingTds = transactions.reduce((acc, t) => acc + (t.tdsDeducted || 0), 0);

    return (
       <div className="space-y-6 animate-in fade-in duration-500">
          <div className="bg-slate-800 text-white p-6 rounded-xl mb-6 flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold">Finance Control Center</h2>
              <p className="text-slate-300 text-sm mt-1">Overview of Cash Flow, Approvals & Compliance</p>
            </div>
            <div className="flex gap-2">
               <span className="bg-emerald-500/20 border border-emerald-500/50 px-3 py-1 rounded text-emerald-300 text-sm">FCRA Active</span>
            </div>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatCard title="Cash Inflow" value={`₹${totalFunds.toLocaleString()}`} icon={IndianRupee} color="bg-emerald-600" trend="up" trendValue={8} />
            <StatCard title="Cash Outflow" value={`₹${totalExpenses.toLocaleString()}`} icon={TrendingUp} color="bg-red-600" trend="down" trendValue={2} />
            <StatCard title="Approvals Pending" value={pendingApprovals} icon={ShieldCheck} color="bg-amber-500" subtitle="Beneficiary Cases" />
            <StatCard title="TDS Liability" value={`₹${pendingTds.toLocaleString()}`} icon={FileText} color="bg-blue-600" subtitle="Due Next Month" />
         </div>

         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-100">
               <div className="flex justify-between items-center mb-4">
                  <h3 className="font-bold text-slate-800">Pending Beneficiary Approvals</h3>
                  <button className="text-blue-600 text-sm font-medium flex items-center gap-1">View All <ArrowRight className="w-4 h-4"/></button>
               </div>
               <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                     <thead className="bg-slate-50 text-slate-600">
                        <tr>
                           <th className="px-4 py-2">Name</th>
                           <th className="px-4 py-2">Type</th>
                           <th className="px-4 py-2">Amount</th>
                           <th className="px-4 py-2">Priority</th>
                           <th className="px-4 py-2">Action</th>
                        </tr>
                     </thead>
                     <tbody className="divide-y divide-slate-100">
                        {beneficiaries.filter(b => b.status === CaseStatus.SUBMITTED).slice(0, 5).map(b => (
                           <tr key={b.id}>
                              <td className="px-4 py-3 font-medium">{b.name}</td>
                              <td className="px-4 py-3">{b.caseType}</td>
                              <td className="px-4 py-3 font-bold">₹{b.financials?.requestedAmount}</td>
                              <td className="px-4 py-3">
                                 <span className={`text-[10px] px-2 py-1 rounded font-bold ${b.priority === 'Urgent' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600'}`}>{b.priority}</span>
                              </td>
                              <td className="px-4 py-3">
                                 <span className="text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded hover:bg-blue-100 cursor-pointer">Review</span>
                              </td>
                           </tr>
                        ))}
                        {beneficiaries.filter(b => b.status === CaseStatus.SUBMITTED).length === 0 && (
                           <tr><td colSpan={5} className="p-4 text-center text-slate-400">No pending approvals.</td></tr>
                        )}
                     </tbody>
                  </table>
               </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
               <h3 className="font-bold text-slate-800 mb-4">Recent Transactions</h3>
               <div className="space-y-3">
                  {transactions.slice(0, 5).map(t => (
                     <div key={t.id} className="flex justify-between items-center text-sm border-b border-slate-50 pb-2">
                        <div>
                           <div className="font-medium text-slate-700 truncate w-32">{t.description}</div>
                           <div className="text-xs text-slate-400">{t.date}</div>
                        </div>
                        <div className={`font-bold ${t.type === 'Expense' ? 'text-red-600' : 'text-emerald-600'}`}>
                           {t.type === 'Expense' ? '-' : '+'}₹{Math.abs(t.amount)}
                        </div>
                     </div>
                  ))}
               </div>
            </div>
         </div>
       </div>
    );
  }

  // --- Role: Admin / Generic Dashboard ---
  const totalFunds = transactions.reduce((acc, t) => t.type !== 'Expense' ? acc + t.amount : acc, 0);
  const activeProjects = projects.filter(p => p.status === Status.ACTIVE).length;
  const criticalCases = beneficiaries.filter(b => b.status === Status.CRITICAL).length;
  
  const projectStatusData = [
    { name: 'Active', value: projects.filter(p => p.status === Status.ACTIVE).length },
    { name: 'Pending', value: projects.filter(p => p.status === Status.PENDING).length },
    { name: 'Completed', value: projects.filter(p => p.status === Status.COMPLETED).length },
    { name: 'Critical', value: projects.filter(p => p.status === Status.CRITICAL).length },
  ];

  const fundsData = [
    { name: 'Jul', income: 4000, expense: 2400 },
    { name: 'Aug', income: 3000, expense: 1398 },
    { name: 'Sep', income: 9800, expense: 6800 },
    { name: 'Oct', income: totalFunds / 4, expense: totalFunds / 5 },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="bg-white p-4 rounded-xl mb-4 border border-slate-200">
         <h2 className="text-xl font-bold text-slate-800">Executive Dashboard</h2>
         <p className="text-slate-500 text-sm">Global Overview for {currentUser.role}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Donations" value={`₹${totalFunds.toLocaleString()}`} icon={IndianRupee} trend="up" trendValue={12} color="bg-emerald-500" />
        <StatCard title="Active Projects" value={activeProjects} icon={Package} trend="neutral" trendValue={0} color="bg-blue-500" />
        <StatCard title="Beneficiaries" value={beneficiaries.length} icon={Users} trend="up" trendValue={5} color="bg-indigo-500" />
        <StatCard title="Critical Alerts" value={criticalCases} icon={AlertCircle} trend="down" trendValue={2} color="bg-red-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Financial Overview</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={fundsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" stroke="#64748b" />
                <YAxis stroke="#64748b" />
                <Tooltip contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                <Legend />
                <Bar dataKey="income" fill="#10b981" name="Income" radius={[4, 4, 0, 0]} />
                <Bar dataKey="expense" fill="#ef4444" name="Expense" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Project Health</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={projectStatusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                >
                  {projectStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
