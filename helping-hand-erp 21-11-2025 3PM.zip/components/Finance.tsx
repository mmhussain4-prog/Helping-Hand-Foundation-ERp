
import React, { useState, useMemo } from 'react';
import { Transaction, Project, Beneficiary } from '../types';
import { MOCK_BENEFICIARIES, MOCK_PROJECTS, MOCK_COMPLIANCE } from '../services/mockData';
import { FinanceEntryForm } from './FinanceEntryForm';
import { 
  Search, Filter, ArrowUpRight, ArrowDownLeft, Download, 
  Landmark, FileText, CreditCard, Briefcase, CheckCircle, 
  AlertCircle, Upload, Plus, ShieldCheck, Calendar, Users, Settings, X, Trash2, IndianRupee, FileSpreadsheet, BarChart3, PieChart as PieIcon, LayoutDashboard
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';

interface FinanceProps {
  transactions: Transaction[];
}

// Tabs configuration
type Tab = 'dashboard' | 'overview' | 'ledger' | 'banking' | 'compliance' | 'payroll';

export const Finance: React.FC<FinanceProps> = ({ transactions: initialTransactions }) => {
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [isEntryModalOpen, setIsEntryModalOpen] = useState(false);
  
  // Feature States
  const [expenseHeads, setExpenseHeads] = useState(['Rent', 'Travel', 'Office Supplies', 'Medical Aid', 'Salary', 'Utilities', 'Maintenance', 'Legal & Prof', 'Payroll', 'Consultancy Fees', 'Widow Support', 'Orphan Support', 'Bulk Payments']);
  const [incomeHeads, setIncomeHeads] = useState(['General Donation', 'Corpus Fund', 'Grant', 'Interest', 'Membership Fees', 'CSR Funding', 'FCRA Donation']);
  
  const [isManageHeadsOpen, setIsManageHeadsOpen] = useState(false);
  const [newLedgerHead, setNewLedgerHead] = useState('');
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);
  
  // Mock Projects/Beneficiaries for dropdowns
  const projects = MOCK_PROJECTS;
  const beneficiaries = MOCK_BENEFICIARIES;

  // --- Derived Stats ---
  const stats = useMemo(() => {
    const income = transactions.filter(t => t.type === 'Donation' || t.type === 'Grant').reduce((acc, t) => acc + t.amount, 0);
    const expenses = transactions.filter(t => t.type === 'Expense' || t.type === 'Salary').reduce((acc, t) => acc + Math.abs(t.amount), 0);
    const tdsPayable = transactions.reduce((acc, t) => acc + (t.tdsDeducted || 0), 0); // Simplified logic: cumulative liability
    
    return { income, expenses, tdsPayable };
  }, [transactions]);

  const handleNewTransaction = (data: Partial<Transaction>) => {
    const newTx: Transaction = {
      id: `T${Math.floor(Math.random() * 10000)}`,
      date: data.date || new Date().toISOString(),
      type: data.type || 'Expense',
      description: data.description || '',
      category: data.category || 'General',
      amount: data.amount || 0,
      paymentMode: data.paymentMode || 'NEFT/RTGS',
      reconciled: false,
      grossAmount: data.grossAmount,
      tdsDeducted: data.tdsDeducted,
      tdsSection: data.tdsSection,
      linkedProjectId: data.linkedProjectId,
      linkedBeneficiaryId: data.linkedBeneficiaryId,
      bankReference: data.bankReference
    };
    setTransactions([newTx, ...transactions]);
    setIsEntryModalOpen(false);
  };

  const addLedgerHead = () => {
    if (newLedgerHead && !expenseHeads.includes(newLedgerHead)) {
      setExpenseHeads([...expenseHeads, newLedgerHead]);
      setNewLedgerHead('');
    }
  };

  const removeLedgerHead = (head: string) => {
    setExpenseHeads(expenseHeads.filter(h => h !== head));
  };

  // --- Sub-components for Tabs ---

  const DashboardTab = () => {
    // Mock data for visualizations based on likely patterns
    const trendData = [
      { name: 'Jul', income: 45000, expense: 32000 },
      { name: 'Aug', income: 52000, expense: 38000 },
      { name: 'Sep', income: 48000, expense: 42000 },
      { name: 'Oct', income: 61000, expense: 45000 },
      { name: 'Nov', income: 55000, expense: 39000 },
    ];

    const projectBudgetData = projects.map(p => ({
      name: p.name.substring(0, 15) + '...',
      budget: p.approvedBudget + p.carryForward,
      actual: p.spent
    }));

    const tdsSummaryData = [
      { name: '194C (Contractors)', value: 4500 },
      { name: '194J (Professional)', value: 12500 },
      { name: '192 (Salary)', value: 8500 },
      { name: '194I (Rent)', value: 3000 },
    ];

    const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

    return (
      <div className="space-y-6 animate-in fade-in duration-300">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-600" /> Income vs. Expense Trends
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={trendData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" stroke="#64748b" />
                <YAxis stroke="#64748b" />
                <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                <Legend />
                <Bar dataKey="income" fill="#10b981" name="Income" radius={[4, 4, 0, 0]} />
                <Bar dataKey="expense" fill="#ef4444" name="Expense" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="font-bold text-slate-800 mb-6">Project Budget vs Actuals</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={projectBudgetData} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                  <XAxis type="number" stroke="#64748b" />
                  <YAxis dataKey="name" type="category" width={100} stroke="#64748b" style={{ fontSize: '12px' }} />
                  <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ borderRadius: '8px' }} />
                  <Legend />
                  <Bar dataKey="budget" fill="#3b82f6" name="Total Budget" barSize={20} radius={[0, 4, 4, 0]} />
                  <Bar dataKey="actual" fill="#f59e0b" name="Actual Spent" barSize={20} radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="font-bold text-slate-800 mb-6">TDS Liability Distribution</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={tdsSummaryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {tdsSummaryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: '8px' }} />
                  <Legend layout="vertical" verticalAlign="middle" align="right" />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const OverviewTab = () => (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-4">
               <h3 className="text-slate-500 font-medium text-sm">Total Bank Balance (Book)</h3>
               <Landmark className="w-5 h-5 text-blue-600" />
            </div>
            <div className="text-3xl font-bold text-slate-800">₹{(stats.income - stats.expenses).toLocaleString()}</div>
            <div className="text-xs text-slate-400 mt-2">Updated today</div>
         </div>
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-4">
               <h3 className="text-slate-500 font-medium text-sm">Pending TDS Liability</h3>
               <ShieldCheck className="w-5 h-5 text-amber-600" />
            </div>
            <div className="text-3xl font-bold text-slate-800">₹{stats.tdsPayable.toLocaleString()}</div>
            <div className="text-xs text-amber-600 mt-2">Due by 7th of next month</div>
         </div>
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-4">
               <h3 className="text-slate-500 font-medium text-sm">Monthly Burn Rate</h3>
               <ArrowDownLeft className="w-5 h-5 text-red-600" />
            </div>
            <div className="text-3xl font-bold text-slate-800">₹8,500</div>
            <div className="text-xs text-slate-400 mt-2">Avg based on last 3 months</div>
         </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex justify-between items-center">
           <h3 className="font-bold text-slate-800">Recent Ledger Activity</h3>
           <button onClick={() => setActiveTab('ledger')} className="text-sm text-blue-600 hover:text-blue-700 font-medium">View All</button>
        </div>
        <table className="w-full text-sm text-left">
           <thead className="bg-slate-50 text-slate-600">
              <tr>
                 <th className="px-6 py-3 font-medium">Date</th>
                 <th className="px-6 py-3 font-medium">Description</th>
                 <th className="px-6 py-3 font-medium">Gross</th>
                 <th className="px-6 py-3 font-medium text-right">Net Amount</th>
              </tr>
           </thead>
           <tbody className="divide-y divide-slate-100">
              {transactions.slice(0, 5).map(t => (
                <tr key={t.id}>
                   <td className="px-6 py-3 text-slate-500">{t.date}</td>
                   <td className="px-6 py-3 text-slate-800">{t.description}</td>
                   <td className="px-6 py-3 text-slate-500">₹{(t.grossAmount || Math.abs(t.amount)).toLocaleString()}</td>
                   <td className={`px-6 py-3 text-right font-bold ${t.type === 'Expense' ? 'text-red-600' : 'text-emerald-600'}`}>
                      {t.type === 'Expense' ? '-' : '+'}₹{Math.abs(t.amount).toLocaleString()}
                   </td>
                </tr>
              ))}
           </tbody>
        </table>
      </div>
    </div>
  );

  const LedgerTab = () => (
    <div className="space-y-4 animate-in fade-in duration-300">
      <div className="flex gap-3 mb-4">
         <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input type="text" placeholder="Search ledger entries..." className="w-full pl-10 p-2 border border-slate-200 rounded-lg text-sm" />
         </div>
         <button onClick={() => setIsManageHeadsOpen(true)} className="px-4 py-2 border border-slate-200 rounded-lg bg-white flex items-center gap-2 text-sm text-slate-600 hover:bg-slate-50">
            <Settings className="w-4 h-4" /> Manage Expense Categories
         </button>
         <button onClick={() => setIsBulkUploadOpen(true)} className="px-4 py-2 border border-slate-200 rounded-lg bg-white flex items-center gap-2 text-sm text-slate-600 hover:bg-slate-50">
            <Upload className="w-4 h-4" /> Bulk Upload
         </button>
         <button className="px-4 py-2 border border-slate-200 rounded-lg bg-white flex items-center gap-2 text-sm text-slate-600">
            <Download className="w-4 h-4" /> Export
         </button>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
         <table className="w-full text-sm text-left">
           <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
              <tr>
                 <th className="px-4 py-3">Date / ID</th>
                 <th className="px-4 py-3">Particulars</th>
                 <th className="px-4 py-3">Allocation</th>
                 <th className="px-4 py-3 text-right">Gross</th>
                 <th className="px-4 py-3 text-right">TDS</th>
                 <th className="px-4 py-3 text-right">Net Pay/Rec</th>
                 <th className="px-4 py-3">Mode</th>
              </tr>
           </thead>
           <tbody className="divide-y divide-slate-100">
              {transactions.map(t => (
                <tr key={t.id} className="hover:bg-slate-50/50">
                   <td className="px-4 py-3">
                      <div className="font-medium text-slate-800">{t.date}</div>
                      <div className="text-xs text-slate-400 font-mono">{t.id}</div>
                   </td>
                   <td className="px-4 py-3">
                      <div className="font-medium text-slate-800">{t.description}</div>
                      <div className="text-xs text-slate-500">{t.category} {t.invoiceUrl && '• Inv attached'}</div>
                   </td>
                   <td className="px-4 py-3">
                      {t.linkedProjectId ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-50 text-blue-700">
                           Project: {projects.find(p => p.id === t.linkedProjectId)?.name || t.linkedProjectId}
                        </span>
                      ) : t.linkedBeneficiaryId ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-indigo-50 text-indigo-700">
                           Beneficiary: {t.linkedBeneficiaryId}
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400">General Admin</span>
                      )}
                   </td>
                   <td className="px-4 py-3 text-right text-slate-600">
                      ₹{(t.grossAmount || Math.abs(t.amount)).toLocaleString()}
                   </td>
                   <td className="px-4 py-3 text-right text-amber-600">
                      {t.tdsDeducted ? `-${t.tdsDeducted}` : '-'}
                   </td>
                   <td className={`px-4 py-3 text-right font-bold ${t.type === 'Expense' || t.type === 'Salary' ? 'text-red-600' : 'text-emerald-600'}`}>
                      {Math.abs(t.amount).toLocaleString()}
                   </td>
                   <td className="px-4 py-3 text-slate-500 text-xs">
                      {t.paymentMode}
                      {t.bankReference && <div className="mt-0.5 font-mono text-[10px]">{t.bankReference}</div>}
                   </td>
                </tr>
              ))}
           </tbody>
         </table>
      </div>
    </div>
  );

  const BankingTab = () => (
    <div className="space-y-6 animate-in fade-in duration-300">
       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Balances */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
             <h3 className="text-slate-800 font-bold mb-4 flex items-center gap-2">
               <Landmark className="w-5 h-5 text-blue-600" /> Balance Summary
             </h3>
             <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                   <span className="text-sm text-slate-600">Book Balance</span>
                   <span className="font-bold text-slate-800">₹{(stats.income - stats.expenses).toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-lg border border-emerald-100">
                   <span className="text-sm text-emerald-800">Bank Balance (As per Statement)</span>
                   <span className="font-bold text-emerald-800">₹41,200.00</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-slate-100">
                   <span className="text-xs font-medium text-slate-500">Unreconciled Difference</span>
                   <span className="font-bold text-red-600 text-sm">₹2,300.00</span>
                </div>
             </div>
          </div>

          {/* Upload & Actions */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-center items-center text-center">
             <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mb-3">
                <Upload className="w-6 h-6 text-blue-600" />
             </div>
             <h3 className="text-slate-800 font-bold mb-1">Upload Bank Statement</h3>
             <p className="text-slate-500 text-xs mb-4">Upload PDF/CSV to auto-reconcile transactions.</p>
             <button className="bg-white border border-slate-300 text-slate-700 px-4 py-2 rounded-lg hover:bg-slate-50 text-sm font-medium w-full max-w-xs">
                Select File...
             </button>
          </div>
       </div>

       {/* Unreconciled Items */}
       <div className="bg-white rounded-xl shadow-sm border border-slate-200">
          <div className="p-4 border-b border-slate-100">
             <h3 className="font-bold text-slate-800 text-sm">Unreconciled Transactions</h3>
          </div>
          <table className="w-full text-sm text-left">
             <thead className="bg-slate-50 text-slate-600">
                <tr>
                  <th className="px-4 py-2">Date</th>
                  <th className="px-4 py-2">Particulars</th>
                  <th className="px-4 py-2 text-right">Amount</th>
                  <th className="px-4 py-2 text-center">Action</th>
                </tr>
             </thead>
             <tbody className="divide-y divide-slate-100">
                {transactions.filter(t => !t.reconciled).map(t => (
                   <tr key={t.id}>
                      <td className="px-4 py-3 text-slate-500">{t.date}</td>
                      <td className="px-4 py-3 font-medium">{t.description}</td>
                      <td className="px-4 py-3 text-right font-bold">₹{Math.abs(t.amount)}</td>
                      <td className="px-4 py-3 text-center">
                         <button className="text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded hover:bg-blue-100">Reconcile</button>
                      </td>
                   </tr>
                ))}
             </tbody>
          </table>
       </div>
    </div>
  );

  const ComplianceTab = () => (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         {MOCK_COMPLIANCE.map(c => (
            <div key={c.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden">
               <div className={`absolute top-0 right-0 px-3 py-1 text-[10px] font-bold uppercase rounded-bl-lg ${
                 c.status === 'Filed' ? 'bg-emerald-100 text-emerald-700' : 
                 c.status === 'Overdue' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
               }`}>
                 {c.status}
               </div>
               <h4 className="font-bold text-slate-800 flex items-center gap-2">
                 <FileText className="w-4 h-4 text-slate-400" /> {c.type}
               </h4>
               <div className="mt-3 space-y-1 text-sm">
                  <p className="text-slate-500">Period: <span className="font-medium text-slate-700">{c.period}</span></p>
                  <p className="text-slate-500">Due Date: <span className="text-red-600 font-medium">{c.dueDate}</span></p>
               </div>
               {c.status === 'Pending' && (
                 <button className="mt-4 w-full py-2 text-xs bg-slate-800 text-white rounded hover:bg-slate-700">Mark as Filed</button>
               )}
            </div>
         ))}
      </div>

      <div className="bg-slate-50 border border-slate-200 rounded-xl p-6">
         <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-blue-600" /> Statutory Liability Summary (Indian Standards)
         </h3>
         <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded border border-slate-200">
               <div className="text-xs text-slate-500 uppercase font-bold">TDS (Contractors)</div>
               <div className="text-xl font-bold text-slate-800 mt-1">₹ 45,000</div>
               <div className="text-[10px] text-slate-400">Section 194C</div>
            </div>
            <div className="bg-white p-4 rounded border border-slate-200">
               <div className="text-xs text-slate-500 uppercase font-bold">TDS (Professional)</div>
               <div className="text-xl font-bold text-slate-800 mt-1">₹ 12,500</div>
               <div className="text-[10px] text-slate-400">Section 194J</div>
            </div>
            <div className="bg-white p-4 rounded border border-slate-200">
               <div className="text-xs text-slate-500 uppercase font-bold">Provident Fund</div>
               <div className="text-xl font-bold text-slate-800 mt-1">₹ 8,200</div>
               <div className="text-[10px] text-slate-400">Employer + Employee</div>
            </div>
         </div>
      </div>
    </div>
  );

  const PayrollTab = () => (
    <div className="space-y-4 animate-in fade-in duration-300">
       <div className="flex justify-end">
         <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2">
           <Plus className="w-4 h-4" /> Process Payroll
         </button>
       </div>
       <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
         <table className="w-full text-sm text-left">
           <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
              <tr>
                 <th className="px-6 py-3">Employee</th>
                 <th className="px-6 py-3">Role</th>
                 <th className="px-6 py-3 text-right">Basic Salary</th>
                 <th className="px-6 py-3 text-right">Deductions</th>
                 <th className="px-6 py-3 text-right">Net Pay</th>
                 <th className="px-6 py-3">Status</th>
              </tr>
           </thead>
           <tbody className="divide-y divide-slate-100">
              <tr>
                 <td className="px-6 py-3 font-medium">Alice M.</td>
                 <td className="px-6 py-3 text-slate-500">Program Head</td>
                 <td className="px-6 py-3 text-right">₹45,000</td>
                 <td className="px-6 py-3 text-right text-red-500">-₹2,500</td>
                 <td className="px-6 py-3 text-right font-bold">₹42,500</td>
                 <td className="px-6 py-3"><span className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full text-xs">Paid</span></td>
              </tr>
              <tr>
                 <td className="px-6 py-3 font-medium">Rajeev K.</td>
                 <td className="px-6 py-3 text-slate-500">Accountant</td>
                 <td className="px-6 py-3 text-right">₹35,000</td>
                 <td className="px-6 py-3 text-right text-red-500">-₹1,800</td>
                 <td className="px-6 py-3 text-right font-bold">₹33,200</td>
                 <td className="px-6 py-3"><span className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full text-xs">Paid</span></td>
              </tr>
           </tbody>
         </table>
       </div>
    </div>
  );

  return (
    <div className="space-y-6">
      
      {/* New Transaction Modal */}
      {isEntryModalOpen && (
        <FinanceEntryForm 
          onCancel={() => setIsEntryModalOpen(false)} 
          onSubmit={handleNewTransaction}
          projects={projects}
          beneficiaries={beneficiaries}
          incomeHeads={incomeHeads}
          expenseHeads={expenseHeads}
        />
      )}

      {/* Manage Ledger Heads Modal */}
      {isManageHeadsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
             <div className="bg-slate-800 p-4 flex justify-between items-center text-white">
                <h3 className="font-bold flex items-center gap-2"><Settings className="w-5 h-5" /> Manage Expense Categories</h3>
                <button onClick={() => setIsManageHeadsOpen(false)} className="hover:bg-slate-700 p-1 rounded"><X className="w-5 h-5" /></button>
             </div>
             <div className="p-4 space-y-4">
                <div className="flex gap-2">
                   <input 
                      className="flex-1 p-2 border border-slate-200 rounded-lg text-sm" 
                      placeholder="New Category Name"
                      value={newLedgerHead}
                      onChange={(e) => setNewLedgerHead(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addLedgerHead()}
                   />
                   <button onClick={addLedgerHead} className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700">
                      <Plus className="w-5 h-5" />
                   </button>
                </div>
                <div className="flex flex-wrap gap-2 max-h-60 overflow-y-auto p-2 border border-slate-100 rounded-lg">
                   {expenseHeads.map(head => (
                      <div key={head} className="bg-slate-100 text-slate-700 px-2 py-1 rounded-md text-xs font-medium flex items-center gap-1 group">
                         {head}
                         <button onClick={() => removeLedgerHead(head)} className="text-slate-400 hover:text-red-500 group-hover:text-red-500">
                            <X className="w-3 h-3" />
                         </button>
                      </div>
                   ))}
                </div>
                <div className="bg-blue-50 p-3 rounded text-xs text-blue-700">
                   These categories will be available in the dropdown when recording new expenses.
                </div>
             </div>
          </div>
        </div>
      )}

      {/* Bulk Upload Modal */}
      {isBulkUploadOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
           <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-200">
              <div className="bg-slate-800 p-4 flex justify-between items-center text-white">
                 <h3 className="font-bold flex items-center gap-2"><Upload className="w-5 h-5" /> Bulk Upload Transactions</h3>
                 <button onClick={() => setIsBulkUploadOpen(false)} className="hover:bg-slate-700 p-1 rounded"><X className="w-5 h-5" /></button>
              </div>
              <div className="p-6 text-center space-y-6">
                 <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 flex flex-col items-center justify-center bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer">
                    <FileSpreadsheet className="w-12 h-12 text-slate-400 mb-3" />
                    <p className="text-slate-600 font-medium">Drag and drop your Excel/CSV file here</p>
                    <p className="text-xs text-slate-400 mt-1">Supports .xlsx, .csv (Max 5MB)</p>
                 </div>
                 <div className="flex justify-between text-sm px-2">
                    <a href="#" className="text-blue-600 hover:underline flex items-center gap-1"><Download className="w-3 h-3" /> Download Template</a>
                 </div>
                 <div className="flex gap-3">
                    <button onClick={() => setIsBulkUploadOpen(false)} className="flex-1 py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50">Cancel</button>
                    <button onClick={() => { alert("Upload simulated!"); setIsBulkUploadOpen(false); }} className="flex-1 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Upload & Process</button>
                 </div>
              </div>
           </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Finance & Grants</h2>
          <p className="text-slate-500 text-sm mt-1">Manage FCRA, bookkeeping, and compliance.</p>
        </div>
        <div className="flex gap-3">
           <div className="bg-slate-100 p-1 rounded-lg flex overflow-x-auto max-w-[200px] sm:max-w-none">
              <button 
                 onClick={() => setActiveTab('dashboard')}
                 className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap flex items-center gap-1 ${activeTab === 'dashboard' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                 <LayoutDashboard className="w-3 h-3" /> Dashboard
              </button>
              {['overview', 'ledger', 'banking', 'compliance', 'payroll'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab as Tab)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium capitalize transition-all whitespace-nowrap ${
                    activeTab === tab ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  {tab}
                </button>
              ))}
           </div>
           <button 
             onClick={() => setIsEntryModalOpen(true)}
             className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 shadow-sm font-medium flex items-center gap-2 shrink-0"
           >
             <Plus className="w-4 h-4" /> New Transaction
           </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="min-h-[400px]">
         {activeTab === 'dashboard' && <DashboardTab />}
         {activeTab === 'overview' && <OverviewTab />}
         {activeTab === 'ledger' && <LedgerTab />}
         {activeTab === 'banking' && <BankingTab />}
         {activeTab === 'compliance' && <ComplianceTab />}
         {activeTab === 'payroll' && <PayrollTab />}
      </div>
    </div>
  );
};