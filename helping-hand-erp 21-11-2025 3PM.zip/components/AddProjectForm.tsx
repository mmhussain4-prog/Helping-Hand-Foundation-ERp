import React, { useState } from 'react';
import { Project, ProjectNature, ProjectCategory, Status } from '../types';
import { X, Save, IndianRupee, Briefcase } from 'lucide-react';

interface AddProjectFormProps {
  onCancel: () => void;
  onSubmit: (project: Project) => void;
}

export const AddProjectForm: React.FC<AddProjectFormProps> = ({ onCancel, onSubmit }) => {
  const [formData, setFormData] = useState<Partial<Project>>({
    name: '',
    nature: 'FCRA',
    category: 'Medical',
    status: Status.PENDING,
    approvedBudget: 0,
    carryForward: 0,
    spent: 0,
    monthlyExpenses: 0,
    predictedBudget: 0,
    manager: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Basic validation
    if (!formData.name || !formData.approvedBudget) return;

    onSubmit({
      id: `P${Math.floor(Math.random() * 10000)}`,
      ...formData as Project,
      spent: 0,
      monthlyExpenses: 0
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="bg-slate-800 p-4 flex justify-between items-center text-white">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <Briefcase className="w-5 h-5" /> New Project
          </h3>
          <button onClick={onCancel} className="hover:bg-slate-700 p-1 rounded transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          
          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">Project Name</label>
              <input 
                type="text" 
                required
                className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="e.g., Rural Health Camp 2024"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Nature of Project</label>
              <select 
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                value={formData.nature}
                onChange={e => setFormData({...formData, nature: e.target.value as ProjectNature})}
              >
                <option value="FCRA">FCRA</option>
                <option value="CSR">CSR</option>
                <option value="Family Philanthropy">Family Philanthropy</option>
                <option value="Local Donations">Local Donations</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Category</label>
              <select 
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                value={formData.category}
                onChange={e => setFormData({...formData, category: e.target.value as ProjectCategory})}
              >
                <option value="Medical">Medical</option>
                <option value="Scholarships">Scholarships</option>
                <option value="Educational Support">Educational Support</option>
                <option value="HHF School">HHF School</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Project Manager</label>
              <input 
                type="text" 
                className="w-full p-2 border border-slate-200 rounded-lg"
                placeholder="Manager Name"
                value={formData.manager}
                onChange={e => setFormData({...formData, manager: e.target.value})}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Status</label>
              <select 
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                value={formData.status}
                onChange={e => setFormData({...formData, status: e.target.value as Status})}
              >
                {Object.values(Status).map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>

          <div className="h-px bg-slate-100 my-4"></div>

          {/* Financials */}
          <div>
            <h4 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
              <IndianRupee className="w-4 h-4 text-emerald-600" /> Financial Planning
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Approved Budget</label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400">₹</span>
                  <input 
                    type="number" 
                    required
                    className="w-full pl-7 p-2 border border-slate-200 rounded-lg font-medium"
                    placeholder="0.00"
                    value={formData.approvedBudget}
                    onChange={e => setFormData({...formData, approvedBudget: parseFloat(e.target.value)})}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Carry Forward (Prev Year)</label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400">₹</span>
                  <input 
                    type="number" 
                    className="w-full pl-7 p-2 border border-slate-200 rounded-lg"
                    placeholder="0.00"
                    value={formData.carryForward}
                    onChange={e => setFormData({...formData, carryForward: parseFloat(e.target.value)})}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase mb-1">Next Year Predicted Budget</label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400">₹</span>
                  <input 
                    type="number" 
                    className="w-full pl-7 p-2 border border-slate-200 rounded-lg bg-slate-50"
                    placeholder="Based on trends"
                    value={formData.predictedBudget}
                    onChange={e => setFormData({...formData, predictedBudget: parseFloat(e.target.value)})}
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">Optional: AI can estimate this later based on expenses.</p>
              </div>
            </div>
          </div>

          <div className="pt-4 flex gap-3">
            <button type="button" onClick={onCancel} className="flex-1 py-2 border border-slate-200 rounded-lg text-slate-600 font-medium hover:bg-slate-50">
              Cancel
            </button>
            <button type="submit" className="flex-1 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 shadow-sm">
              Create Project
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};