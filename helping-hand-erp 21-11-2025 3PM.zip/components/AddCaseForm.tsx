
import React, { useState, useMemo } from 'react';
import { CaseType, MedicalSubCategory, FamilyMember, FinancialArrangement, FinancialItem, Priority } from '../types';
import { Save, X, Plus, Trash2, Upload, AlertCircle, ChevronRight, Home, IndianRupee, Users, FileText, Clock } from 'lucide-react';

interface AddCaseFormProps {
  onCancel: () => void;
  onSubmit: (data: any) => void;
}

export const AddCaseForm: React.FC<AddCaseFormProps> = ({ onCancel, onSubmit }) => {
  // --- State ---
  const [step, setStep] = useState(1);
  
  // Step 1: Basic Info
  const [basicInfo, setBasicInfo] = useState({
    name: '',
    contact: '',
    location: '',
    address: '',
    caseType: CaseType.MEDICAL,
    priority: Priority.GENERAL,
    subCategory: '' as MedicalSubCategory | '',
    description: '',
    hospital: '',
    doctorName: '',
    marriageDate: '',
    schoolName: '',
    studentGrade: '',
  });

  // Payment Preferences
  const [paymentInfo, setPaymentInfo] = useState({
    paymentType: 'One-Time' as 'One-Time' | 'Recurring',
    recurringStartDate: '',
    recurringEndDate: ''
  });

  // Step 2: Family Demographics & Housing
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [housingDetails, setHousingDetails] = useState({
    status: 'Rent',
    rentAmount: 0, // If rent
    electricityBill: 0,
  });

  // Step 3: Financial Profile
  const [incomeSources, setIncomeSources] = useState<FinancialItem[]>([
    { id: '1', label: 'Primary Salary', amount: 0 }
  ]);
  const [monthlyExpenses, setMonthlyExpenses] = useState<FinancialItem[]>([
    { id: '1', label: 'Food & Groceries', amount: 0 },
    { id: '2', label: 'Rent', amount: 0 },
    { id: '3', label: 'Utilities', amount: 0 }
  ]);
  const [assetLiability, setAssetLiability] = useState({
    assets: '', // text description
    liabilities: '' // text description
  });
  
  // Case Financial Request
  const [requestFinancials, setRequestFinancials] = useState<FinancialArrangement>({
    totalCost: 0,
    ownContribution: 0,
    otherDonors: 0,
    requestedAmount: 0,
    details: ''
  });

  // Step 4: Docs & Eval
  const [documents, setDocuments] = useState<string[]>([]);
  const [recommendation, setRecommendation] = useState('');

  // --- Calculations ---
  const totalMonthlyIncome = useMemo(() => {
    const familyEarnings = familyMembers.reduce((acc, curr) => acc + (curr.earnings || 0), 0);
    const otherSources = incomeSources.reduce((acc, curr) => acc + (curr.amount || 0), 0);
    return familyEarnings + otherSources;
  }, [familyMembers, incomeSources]);

  const totalMonthlyExpenses = useMemo(() => {
    return monthlyExpenses.reduce((acc, curr) => acc + (curr.amount || 0), 0);
  }, [monthlyExpenses]);

  // --- Handlers ---
  
  // Basic Info
  const handleBasicChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setBasicInfo({ ...basicInfo, [e.target.name]: e.target.value });
  };

  // Family
  const addFamilyMember = () => {
    setFamilyMembers([...familyMembers, { 
      name: '', 
      age: 0, 
      gender: 'Male',
      relation: '', 
      isAdult: true,
      education: '',
      occupation: '', 
      earnings: 0 
    }]);
  };

  const updateFamilyMember = (index: number, field: keyof FamilyMember, value: any) => {
    const updated = [...familyMembers];
    updated[index] = { ...updated[index], [field]: value };
    setFamilyMembers(updated);
  };

  const removeFamilyMember = (index: number) => {
    setFamilyMembers(familyMembers.filter((_, i) => i !== index));
  };

  // Financial Items (Income/Expenses)
  const addFinancialItem = (setter: React.Dispatch<React.SetStateAction<FinancialItem[]>>, list: FinancialItem[]) => {
    setter([...list, { id: Math.random().toString(36).substr(2, 9), label: '', amount: 0 }]);
  };

  const updateFinancialItem = (
    setter: React.Dispatch<React.SetStateAction<FinancialItem[]>>, 
    list: FinancialItem[], 
    index: number, 
    field: keyof FinancialItem, 
    value: any
  ) => {
    const updated = [...list];
    updated[index] = { ...updated[index], [field]: field === 'amount' ? parseFloat(value) || 0 : value };
    setter(updated);
  };

  const removeFinancialItem = (setter: React.Dispatch<React.SetStateAction<FinancialItem[]>>, list: FinancialItem[], index: number) => {
    setter(list.filter((_, i) => i !== index));
  };

  // Request Financials
  const handleRequestFinChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setRequestFinancials(prev => {
      const updated = { ...prev, [name]: name === 'details' ? value : parseFloat(value) || 0 };
      if (name !== 'requestedAmount' && name !== 'details') {
        updated.requestedAmount = updated.totalCost - (updated.ownContribution + updated.otherDonors);
      }
      return updated;
    });
  };

  const handleFileToggle = (docName: string) => {
    if (documents.includes(docName)) {
      setDocuments(documents.filter(d => d !== docName));
    } else {
      setDocuments([...documents, docName]);
    }
  };

  // --- Renderers ---

  const renderSteps = () => (
    <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 overflow-x-auto">
      <div className="flex min-w-max gap-4 text-sm">
        {[
          { id: 1, label: 'Basic Info', icon: Users },
          { id: 2, label: 'Family & Housing', icon: Home },
          { id: 3, label: 'Financial Profile', icon: IndianRupee },
          { id: 4, label: 'Review & Eval', icon: FileText },
        ].map(s => (
          <div key={s.id} className={`flex items-center gap-2 ${step >= s.id ? 'text-blue-600 font-bold' : 'text-slate-400'}`}>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center border ${step >= s.id ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-300'}`}>
              <s.icon className="w-3 h-3" />
            </div>
            <span className="hidden sm:inline">{s.label}</span>
            {s.id < 4 && <ChevronRight className="w-4 h-4 text-slate-300" />}
          </div>
        ))}
      </div>
    </div>
  );

  const renderCaseSpecifics = () => {
    switch (basicInfo.caseType) {
      case CaseType.MEDICAL:
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-blue-50/50 p-4 rounded-lg border border-blue-100 mt-4">
            <div>
              <label className="block text-xs font-bold text-blue-800 uppercase mb-1">Medical Category</label>
              <select name="subCategory" value={basicInfo.subCategory} onChange={handleBasicChange} className="w-full p-2 border border-slate-200 rounded text-sm">
                <option value="">Select...</option>
                {['Surgery', 'Medicines', 'Blood', 'Hospital Stay', 'Dialysis', 'Other'].map(opt => <option key={opt} value={opt}>{opt}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-blue-800 uppercase mb-1">Hospital Name</label>
              <input name="hospital" value={basicInfo.hospital} onChange={handleBasicChange} className="w-full p-2 border border-slate-200 rounded text-sm" placeholder="e.g. Civil Hospital" />
            </div>
          </div>
        );
      case CaseType.EDUCATION:
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-blue-50/50 p-4 rounded-lg border border-blue-100 mt-4">
            <div>
              <label className="block text-xs font-bold text-blue-800 uppercase mb-1">Institution / School</label>
              <input name="schoolName" value={basicInfo.schoolName} onChange={handleBasicChange} className="w-full p-2 border border-slate-200 rounded text-sm" />
            </div>
            <div>
              <label className="block text-xs font-bold text-blue-800 uppercase mb-1">Current Grade/Course</label>
              <input name="studentGrade" value={basicInfo.studentGrade} onChange={handleBasicChange} className="w-full p-2 border border-slate-200 rounded text-sm" />
            </div>
          </div>
        );
      default: return null;
    }
  };

  // --- Main Render ---
  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden flex flex-col h-full max-h-[90vh]">
      
      {/* Header */}
      <div className="bg-slate-800 text-white p-4 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">New Beneficiary Application</h2>
          <p className="text-slate-300 text-xs mt-1">Complete Assessment Form</p>
        </div>
        <button onClick={onCancel} className="text-slate-400 hover:text-white">
          <X className="w-6 h-6" />
        </button>
      </div>

      {renderSteps()}

      <div className="p-6 overflow-y-auto flex-1">
        
        {/* STEP 1: BASIC INFO */}
        {step === 1 && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Case Category *</label>
                <select name="caseType" value={basicInfo.caseType} onChange={handleBasicChange} className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500">
                  {Object.values(CaseType).map(type => <option key={type} value={type}>{type}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Priority Level *</label>
                <select name="priority" value={basicInfo.priority} onChange={handleBasicChange} className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500">
                  <option value={Priority.GENERAL}>General</option>
                  <option value={Priority.EMERGENCY}>Emergency</option>
                  <option value={Priority.URGENT}>Urgent</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Applicant Name *</label>
                <input name="name" value={basicInfo.name} onChange={handleBasicChange} className="w-full p-2 border border-slate-200 rounded-lg" placeholder="Full Name" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Contact Number *</label>
                <input name="contact" value={basicInfo.contact} onChange={handleBasicChange} className="w-full p-2 border border-slate-200 rounded-lg" placeholder="Mobile" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Area / Location *</label>
                <input name="location" value={basicInfo.location} onChange={handleBasicChange} className="w-full p-2 border border-slate-200 rounded-lg" placeholder="Neighborhood/District" />
              </div>
              <div className="col-span-full">
                <label className="block text-sm font-medium text-slate-700 mb-1">Full Residential Address</label>
                <textarea name="address" value={basicInfo.address} onChange={handleBasicChange} className="w-full p-2 border border-slate-200 rounded-lg h-20" />
              </div>
            </div>
            {renderCaseSpecifics()}
          </div>
        )}

        {/* STEP 2: FAMILY & HOUSING */}
        {step === 2 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
            
            {/* Family Table */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-lg font-bold text-slate-800">Family Demographics</h3>
                <button onClick={addFamilyMember} className="text-sm bg-blue-50 text-blue-600 px-3 py-1.5 rounded hover:bg-blue-100 font-medium flex items-center gap-1">
                  <Plus className="w-3 h-3" /> Add Member
                </button>
              </div>
              
              <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white shadow-sm">
                <table className="w-full text-sm text-left">
                  <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="p-3 min-w-[150px]">Name & Relation</th>
                      <th className="p-3 min-w-[120px]">Details</th>
                      <th className="p-3 min-w-[150px]">Education / Job</th>
                      <th className="p-3 min-w-[100px]">Earnings</th>
                      <th className="p-3 w-10"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {familyMembers.map((m, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50">
                        <td className="p-3 space-y-2">
                          <input value={m.name} onChange={(e) => updateFamilyMember(idx, 'name', e.target.value)} className="w-full p-1.5 border border-slate-200 rounded text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500" placeholder="Full Name" />
                          <input value={m.relation} onChange={(e) => updateFamilyMember(idx, 'relation', e.target.value)} className="w-full p-1.5 border border-slate-200 rounded text-xs" placeholder="Relation (e.g. Son)" />
                        </td>
                        <td className="p-3 space-y-2">
                          <div className="flex gap-2">
                            <input type="number" value={m.age} onChange={(e) => updateFamilyMember(idx, 'age', e.target.value)} className="w-16 p-1.5 border border-slate-200 rounded text-sm" placeholder="Age" />
                            <select value={m.gender} onChange={(e) => updateFamilyMember(idx, 'gender', e.target.value)} className="flex-1 p-1.5 border border-slate-200 rounded text-sm">
                              <option value="Male">Male</option>
                              <option value="Female">Female</option>
                              <option value="Other">Other</option>
                            </select>
                          </div>
                          <label className="flex items-center gap-2 text-xs cursor-pointer">
                            <input type="checkbox" checked={m.isAdult} onChange={(e) => updateFamilyMember(idx, 'isAdult', e.target.checked)} className="rounded text-blue-600 focus:ring-blue-500" />
                            <span className="text-slate-600">Is Adult?</span>
                          </label>
                        </td>
                        <td className="p-3 space-y-2">
                          <input 
                             value={m.education} 
                             onChange={(e) => updateFamilyMember(idx, 'education', e.target.value)} 
                             className="w-full p-1.5 border border-slate-200 rounded text-sm" 
                             placeholder={m.isAdult ? "Highest Qualification" : "Current Schooling/Grade"} 
                          />
                          {m.isAdult && (
                             <input value={m.occupation} onChange={(e) => updateFamilyMember(idx, 'occupation', e.target.value)} className="w-full p-1.5 border border-slate-200 rounded text-xs" placeholder="Occupation" />
                          )}
                        </td>
                        <td className="p-3 align-top">
                          <div className="relative">
                             <span className="absolute left-2 top-1.5 text-slate-400 text-xs">₹</span>
                             <input type="number" value={m.earnings} onChange={(e) => updateFamilyMember(idx, 'earnings', e.target.value)} className="w-full pl-5 p-1.5 border border-slate-200 rounded text-sm font-medium" placeholder="0" />
                          </div>
                        </td>
                        <td className="p-3 text-center align-middle">
                          <button onClick={() => removeFamilyMember(idx)} className="text-slate-400 hover:text-red-500 p-1"><Trash2 className="w-4 h-4" /></button>
                        </td>
                      </tr>
                    ))}
                    {familyMembers.length === 0 && (
                      <tr><td colSpan={5} className="p-6 text-center text-slate-400 text-sm">No family members added yet.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Housing Info */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5">
               <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wide mb-4 flex items-center gap-2">
                 <Home className="w-4 h-4 text-slate-500" /> Housing & Utilities
               </h3>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Housing Status</label>
                    <select 
                      value={housingDetails.status} 
                      onChange={(e) => setHousingDetails({...housingDetails, status: e.target.value})} 
                      className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                    >
                      <option value="Own">Own House</option>
                      <option value="Rent">Rented</option>
                      <option value="Free/Relative">Living Free/With Relatives</option>
                      <option value="Homeless">Homeless/Temporary Shelter</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Monthly Rent (if any)</label>
                    <input 
                      type="number" 
                      value={housingDetails.rentAmount} 
                      disabled={housingDetails.status !== 'Rent'}
                      onChange={(e) => setHousingDetails({...housingDetails, rentAmount: parseFloat(e.target.value)})} 
                      className="w-full p-2 border border-slate-200 rounded-lg bg-white disabled:bg-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Avg. Electricity Bill</label>
                    <input 
                      type="number" 
                      value={housingDetails.electricityBill} 
                      onChange={(e) => setHousingDetails({...housingDetails, electricityBill: parseFloat(e.target.value)})} 
                      className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                    />
                  </div>
               </div>
            </div>
          </div>
        )}

        {/* STEP 3: FINANCIAL PROFILE */}
        {step === 3 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* Income Section */}
              <div className="space-y-3">
                <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                  <h3 className="font-bold text-emerald-700">Income Sources (Direct/Indirect)</h3>
                  <button onClick={() => addFinancialItem(setIncomeSources, incomeSources)} className="text-xs bg-emerald-50 text-emerald-700 px-2 py-1 rounded hover:bg-emerald-100 font-medium">
                    + Add Source
                  </button>
                </div>
                <div className="space-y-2">
                   {/* Read-only total family earnings first */}
                   <div className="flex justify-between items-center p-3 bg-slate-50 rounded border border-slate-200">
                      <span className="text-sm font-medium text-slate-600">Family Member Earnings</span>
                      <span className="font-bold text-slate-800">₹{familyMembers.reduce((acc, curr) => acc + (curr.earnings || 0), 0)}</span>
                   </div>
                   {incomeSources.map((item, idx) => (
                     <div key={item.id} className="flex gap-2 items-center">
                        <input 
                          value={item.label} 
                          onChange={(e) => updateFinancialItem(setIncomeSources, incomeSources, idx, 'label', e.target.value)}
                          placeholder="Source (e.g. Part-time, Aid)" 
                          className="flex-1 p-2 border border-slate-200 rounded text-sm"
                        />
                        <input 
                          type="number" 
                          value={item.amount} 
                          onChange={(e) => updateFinancialItem(setIncomeSources, incomeSources, idx, 'amount', e.target.value)}
                          placeholder="Amount" 
                          className="w-24 p-2 border border-slate-200 rounded text-sm text-right"
                        />
                        <button onClick={() => removeFinancialItem(setIncomeSources, incomeSources, idx)} className="text-slate-400 hover:text-red-500"><X className="w-4 h-4" /></button>
                     </div>
                   ))}
                   <div className="flex justify-between pt-2 border-t border-slate-100">
                      <span className="font-semibold text-sm text-slate-500">Total Monthly Income:</span>
                      <span className="font-bold text-emerald-600">₹{totalMonthlyIncome.toLocaleString()}</span>
                   </div>
                </div>
              </div>

              {/* Expenses Section */}
              <div className="space-y-3">
                <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                  <h3 className="font-bold text-red-700">Major Monthly Expenses</h3>
                  <button onClick={() => addFinancialItem(setMonthlyExpenses, monthlyExpenses)} className="text-xs bg-red-50 text-red-700 px-2 py-1 rounded hover:bg-red-100 font-medium">
                    + Add Expense
                  </button>
                </div>
                <div className="space-y-2">
                   {monthlyExpenses.map((item, idx) => (
                     <div key={item.id} className="flex gap-2 items-center">
                        <input 
                          value={item.label} 
                          onChange={(e) => updateFinancialItem(setMonthlyExpenses, monthlyExpenses, idx, 'label', e.target.value)}
                          placeholder="Expense Type" 
                          className="flex-1 p-2 border border-slate-200 rounded text-sm"
                        />
                        <input 
                          type="number" 
                          value={item.amount} 
                          onChange={(e) => updateFinancialItem(setMonthlyExpenses, monthlyExpenses, idx, 'amount', e.target.value)}
                          placeholder="Amount" 
                          className="w-24 p-2 border border-slate-200 rounded text-sm text-right"
                        />
                        <button onClick={() => removeFinancialItem(setMonthlyExpenses, monthlyExpenses, idx)} className="text-slate-400 hover:text-red-500"><X className="w-4 h-4" /></button>
                     </div>
                   ))}
                   <div className="flex justify-between pt-2 border-t border-slate-100">
                      <span className="font-semibold text-sm text-slate-500">Total Monthly Expense:</span>
                      <span className="font-bold text-red-600">₹{totalMonthlyExpenses.toLocaleString()}</span>
                   </div>
                </div>
              </div>
            </div>

            {/* Net Balance Indicator */}
            <div className="bg-slate-800 text-white p-4 rounded-lg flex justify-between items-center">
               <span className="font-medium">Net Household Balance</span>
               <span className={`text-xl font-bold ${totalMonthlyIncome - totalMonthlyExpenses < 0 ? 'text-red-300' : 'text-emerald-300'}`}>
                 ₹{(totalMonthlyIncome - totalMonthlyExpenses).toLocaleString()} / month
               </span>
            </div>

            {/* Assets & Liabilities */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div>
                 <label className="block text-sm font-bold text-slate-700 mb-2">Assets (Property, Jewelry, Vehicle)</label>
                 <textarea 
                   value={assetLiability.assets}
                   onChange={(e) => setAssetLiability({...assetLiability, assets: e.target.value})}
                   className="w-full p-3 border border-slate-200 rounded-lg text-sm h-24" 
                   placeholder="Describe any significant assets..." 
                 />
               </div>
               <div>
                 <label className="block text-sm font-bold text-slate-700 mb-2">Liabilities (Loans, Debts)</label>
                 <textarea 
                   value={assetLiability.liabilities}
                   onChange={(e) => setAssetLiability({...assetLiability, liabilities: e.target.value})}
                   className="w-full p-3 border border-slate-200 rounded-lg text-sm h-24" 
                   placeholder="Describe debts, to whom, amount..." 
                 />
               </div>
            </div>

            {/* Specific Case Cost */}
            <div className="border-t border-slate-200 pt-6">
               <h3 className="font-bold text-lg text-slate-800 mb-4">Current Application Request</h3>
               <div className="bg-blue-50 border border-blue-100 rounded-xl p-5 grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase">Total Required</label>
                    <input type="number" name="totalCost" value={requestFinancials.totalCost} onChange={handleRequestFinChange} className="w-full p-2 mt-1 border border-slate-200 rounded bg-white font-semibold" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase">Own Contribution</label>
                    <input type="number" name="ownContribution" value={requestFinancials.ownContribution} onChange={handleRequestFinChange} className="w-full p-2 mt-1 border border-slate-200 rounded bg-white" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase">Final Request</label>
                    <div className="w-full p-2 mt-1 bg-blue-100 text-blue-800 font-bold rounded border border-blue-200">
                      ₹{requestFinancials.requestedAmount.toLocaleString()}
                    </div>
                  </div>
               </div>
            </div>

            {/* Payment Preference */}
             <div className="border-t border-slate-200 pt-6">
               <h3 className="font-bold text-lg text-slate-800 mb-4 flex items-center gap-2">
                 <Clock className="w-5 h-5 text-blue-600" /> Payment Structure
               </h3>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div>
                     <label className="block text-sm font-medium text-slate-700 mb-1">Payment Type</label>
                     <select 
                        value={paymentInfo.paymentType} 
                        onChange={(e) => setPaymentInfo({...paymentInfo, paymentType: e.target.value as any})} 
                        className="w-full p-2 border border-slate-200 rounded-lg"
                     >
                        <option value="One-Time">One-Time Payment</option>
                        <option value="Recurring">Recurring (Monthly)</option>
                     </select>
                  </div>
                  {paymentInfo.paymentType === 'Recurring' && (
                    <>
                      <div>
                         <label className="block text-sm font-medium text-slate-700 mb-1">Start Date</label>
                         <input 
                           type="date" 
                           value={paymentInfo.recurringStartDate}
                           onChange={(e) => setPaymentInfo({...paymentInfo, recurringStartDate: e.target.value})}
                           className="w-full p-2 border border-slate-200 rounded-lg" 
                         />
                      </div>
                      <div>
                         <label className="block text-sm font-medium text-slate-700 mb-1">End Date (Till)</label>
                         <input 
                           type="date" 
                           value={paymentInfo.recurringEndDate}
                           onChange={(e) => setPaymentInfo({...paymentInfo, recurringEndDate: e.target.value})}
                           className="w-full p-2 border border-slate-200 rounded-lg" 
                         />
                      </div>
                    </>
                  )}
               </div>
            </div>

          </div>
        )}

        {/* STEP 4: DOCS & EVAL */}
        {step === 4 && (
          <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
             
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
               <div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-3">Required Documents</h3>
                  <div className="space-y-2">
                    {['Beneficiary Photo', 'ID Proof (Aadhar/Voter)', 'Income Proof', 'Diagnosis/Fee Slip', 'Ration Card'].map(doc => (
                      <div key={doc} onClick={() => handleFileToggle(doc)} className={`p-3 border rounded-lg cursor-pointer flex items-center justify-between ${documents.includes(doc) ? 'bg-blue-50 border-blue-300' : 'bg-white hover:bg-slate-50'}`}>
                        <div className="flex items-center gap-3">
                           <Upload className={`w-4 h-4 ${documents.includes(doc) ? 'text-blue-600' : 'text-slate-400'}`} />
                           <span className="text-sm font-medium text-slate-700">{doc}</span>
                        </div>
                        {documents.includes(doc) && <div className="w-2 h-2 rounded-full bg-blue-500"></div>}
                      </div>
                    ))}
                  </div>
               </div>

               <div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-3">Coordinator's Evaluation</h3>
                  <div className="bg-amber-50 border border-amber-100 rounded-lg p-4 mb-4">
                     <div className="flex gap-2 items-start">
                        <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
                        <p className="text-xs text-amber-800 leading-relaxed">
                           Verify that the monthly expenses and stated income match the lifestyle observed during the home visit. 
                           Check for hidden assets or undisclosed income sources.
                        </p>
                     </div>
                  </div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Observation & Recommendation</label>
                  <textarea 
                    value={recommendation}
                    onChange={(e) => setRecommendation(e.target.value)}
                    className="w-full p-3 border border-slate-200 rounded-lg h-40 text-sm focus:ring-2 focus:ring-blue-500"
                    placeholder="Write your detailed assessment here. Is the case genuine? Do they have other support options? Strong recommendation or weak?"
                  ></textarea>
               </div>
             </div>

             <div className="bg-slate-100 p-4 rounded-lg border border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="text-sm text-slate-600">
                   <p><strong>Applicant:</strong> {basicInfo.name}</p>
                   <p><strong>Net Household Balance:</strong> ₹{(totalMonthlyIncome - totalMonthlyExpenses).toLocaleString()}</p>
                   <p><strong>Grant Requested:</strong> ₹{requestFinancials.requestedAmount.toLocaleString()} ({paymentInfo.paymentType})</p>
                </div>
                <div className="flex items-center gap-2">
                   <input type="checkbox" className="w-4 h-4 text-blue-600 rounded" />
                   <span className="text-xs font-semibold text-slate-700">I verify this information is accurate.</span>
                </div>
             </div>
          </div>
        )}

      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-between items-center">
        <button 
          onClick={() => step > 1 ? setStep(step - 1) : onCancel()}
          className="text-slate-500 hover:text-slate-700 px-4 py-2 font-medium"
        >
          {step === 1 ? 'Cancel' : 'Back'}
        </button>
        
        <button 
          onClick={() => step < 4 ? setStep(step + 1) : onSubmit({ 
             ...basicInfo, 
             ...paymentInfo,
             familyMembers, 
             housingDetails, 
             financials: requestFinancials, 
             incomeSources,
             monthlyExpenses,
             assetLiability,
             documents,
             coordinatorRecommendation: recommendation
          })}
          className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2"
        >
          {step === 4 ? (
            <>
              <Save className="w-4 h-4" /> Submit Application
            </>
          ) : (
            <>
              Next <ChevronRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};