import { GoogleGenAI } from "@google/genai";

// Safe initialization that won't crash if key is missing during dev
const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateInsight = async (contextData: string, userPrompt: string): Promise<string> => {
  if (!apiKey) {
    return "AI features require an API Key. Please configure process.env.API_KEY.";
  }

  try {
    const model = 'gemini-2.5-flash';
    const systemPrompt = `You are an expert ERP assistant for a non-profit called 'Helping Hand'.
    Analyze the provided JSON data context and answer the user's specific question.
    Be concise, professional, and data-driven.
    If the user asks for a summary, provide a bulleted list of key risks and opportunities.`;

    const response = await ai.models.generateContent({
      model: model,
      contents: `Context Data: ${contextData}\n\nUser Question: ${userPrompt}`,
      config: {
        systemInstruction: systemPrompt,
      }
    });

    return response.text || "No response generated.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, I encountered an error processing your request.";
  }
};