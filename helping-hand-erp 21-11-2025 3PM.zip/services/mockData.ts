

import { Beneficiary, Project, Status, Transaction, InventoryItem, CaseType, CaseStatus, ComplianceRecord, User, InternalControl, RoleDefinition, Priority } from '../types';

export const MOCK_BENEFICIARIES: Beneficiary[] = [
  { 
    id: 'B001', 
    name: 'Sarah Jenkins', 
    location: 'East District', 
    address: '12B, Elm Street, East District',
    contact: '555-0101', 
    caseType: CaseType.FINANCIAL, 
    status: CaseStatus.APPROVED,
    priority: Priority.GENERAL,
    paymentType: 'One-Time',
    lastInteraction: '2023-10-25', 
    impactScore: 85,
    projectId: 'P001',
    familyMembers: [
      { name: 'Sarah Jenkins', age: 34, gender: 'Female', relation: 'Self', isAdult: true, education: 'High School', occupation: 'House Help', earnings: 300 },
      { name: 'Tom Jenkins', age: 8, gender: 'Male', relation: 'Son', isAdult: false, education: 'Grade 3', occupation: '', earnings: 0 }
    ],
    housingStatus: 'Rent',
    rentAmount: 150,
    electricityBill: 45,
    incomeSources: [{ id: '1', label: 'Salary', amount: 300 }, { id: '2', label: 'Widow Pension', amount: 50 }],
    monthlyExpenses: [{ id: '1', label: 'Rent', amount: 150 }, { id: '2', label: 'Food', amount: 100 }, { id: '3', label: 'School Fees', amount: 30 }],
    assets: 'None',
    liabilities: 'Loan from neighbor (₹200)',
    coordinatorRecommendation: 'Genuine case, single mother struggling with school fees.',
    financials: { totalCost: 500, ownContribution: 100, otherDonors: 0, requestedAmount: 400, details: 'Needs help for medical emergency' }
  },
  { id: 'B002', name: 'Michael Chen', location: 'North Hills', contact: '555-0102', caseType: CaseType.EDUCATION, status: CaseStatus.SUBMITTED, priority: Priority.GENERAL, paymentType: 'Recurring', recurringStartDate: '2023-11-01', recurringEndDate: '2024-11-01', lastInteraction: '2023-10-20', impactScore: 40, projectId: 'P002' },
  { id: 'B003', name: 'Amara Diallo', location: 'Westside', contact: '555-0103', caseType: CaseType.MEDICAL, status: CaseStatus.SUBMITTED, priority: Priority.URGENT, paymentType: 'One-Time', lastInteraction: '2023-10-27', impactScore: 92, projectId: 'P001',
    familyMembers: [
      { name: 'Amara Diallo', age: 45, gender: 'Female', relation: 'Self', isAdult: true, education: 'Uneducated', occupation: 'None', earnings: 0 },
      { name: 'Kofi Diallo', age: 50, gender: 'Male', relation: 'Husband', isAdult: true, education: 'Primary', occupation: 'Daily Wage', earnings: 400 }
    ],
    housingStatus: 'Own',
    electricityBill: 30,
    incomeSources: [{ id: '1', label: 'Husband Labor', amount: 400 }],
    monthlyExpenses: [{ id: '1', label: 'Food', amount: 200 }, { id: '2', label: 'Medicines', amount: 150 }],
    assets: 'Small 1-room house',
    liabilities: 'None',
    coordinatorRecommendation: 'Critical medical condition. Immediate surgery required.',
    financials: { totalCost: 5200, ownContribution: 200, otherDonors: 1000, requestedAmount: 4000, details: 'Surgery scheduled for next week' }
  },
  { id: 'B004', name: 'Juan Rodriguez', location: 'East District', contact: '555-0104', caseType: CaseType.FINANCIAL, status: CaseStatus.DISBURSED, priority: Priority.GENERAL, paymentType: 'One-Time', transactionId: 'UTR-00991', lastInteraction: '2023-10-15', impactScore: 65, projectId: 'P001' },
  { id: 'B005', name: 'Elara Vance', location: 'South Valley', contact: '555-0105', caseType: CaseType.FINANCIAL, status: CaseStatus.CLOSED, priority: Priority.GENERAL, paymentType: 'One-Time', lastInteraction: '2023-09-30', impactScore: 100 },
  { id: 'B006', name: 'Ravi Patel', location: 'Rural Outpost A', contact: '555-0106', caseType: CaseType.FINANCIAL, status: CaseStatus.SUBMITTED, priority: Priority.EMERGENCY, paymentType: 'One-Time', lastInteraction: '2023-10-28', impactScore: 78, projectId: 'P002' },
];

export const MOCK_PROJECTS: Project[] = [
  { 
    id: 'P001', 
    name: 'Clean Water Initiative', 
    nature: 'FCRA',
    category: 'Medical',
    approvedBudget: 50000, 
    carryForward: 5000,
    spent: 35000, 
    monthlyExpenses: 2500,
    predictedBudget: 55000,
    status: Status.ACTIVE, 
    manager: 'Alice M.', 
    lastReportDate: '2023-10-01'
  },
  { 
    id: 'P002', 
    name: 'Rural Education Drive', 
    nature: 'CSR',
    category: 'Educational Support',
    approvedBudget: 120000, 
    carryForward: 12000,
    spent: 45000, 
    monthlyExpenses: 8000,
    predictedBudget: 130000,
    status: Status.ACTIVE, 
    manager: 'Robert K.', 
    lastReportDate: '2023-09-15'
  },
  { 
    id: 'P003', 
    name: 'HHF Model School', 
    nature: 'Family Philanthropy',
    category: 'HHF School',
    approvedBudget: 200000, 
    carryForward: 0,
    spent: 180000, 
    monthlyExpenses: 15000,
    predictedBudget: 220000,
    status: Status.ACTIVE, 
    manager: 'Sarah J.', 
    lastReportDate: '2023-10-20'
  },
  { 
    id: 'P004', 
    name: 'Community Health Camps', 
    nature: 'Local Donations',
    category: 'Medical',
    approvedBudget: 15000, 
    carryForward: 2000,
    spent: 14800, 
    monthlyExpenses: 500,
    predictedBudget: 18000,
    status: Status.COMPLETED, 
    manager: 'Dr. Smith', 
    lastReportDate: '2023-08-30'
  },
  { 
    id: 'P005', 
    name: 'Merit Scholarships 2024', 
    nature: 'CSR',
    category: 'Scholarships',
    approvedBudget: 75000, 
    carryForward: 10000,
    spent: 10000, 
    monthlyExpenses: 1000,
    predictedBudget: 80000,
    status: Status.PENDING, 
    manager: 'Davina L.', 
    lastReportDate: '2023-10-25'
  },
];

export const MOCK_TRANSACTIONS: Transaction[] = [
  { 
    id: 'T1001', date: '2023-10-28', type: 'Donation', amount: 5000, description: 'Individual Donor - Gala', category: 'General Fund', 
    paymentMode: 'Cheque', bankReference: 'CHQ-98821', reconciled: true, grossAmount: 5000, tdsDeducted: 0 
  },
  { 
    id: 'T1002', date: '2023-10-27', type: 'Expense', amount: -1200, description: 'Office Supplies', category: 'Operations', 
    paymentMode: 'UPI', bankReference: 'UPI-123456', reconciled: true, grossAmount: 1200, tdsDeducted: 0 
  },
  { 
    id: 'T1003', date: '2023-10-26', type: 'Grant', amount: 50000, description: 'Global Health Foundation Grant', category: 'FCRA', 
    paymentMode: 'NEFT/RTGS', bankReference: 'UTR-FCRA-001', reconciled: true, grossAmount: 50000, tdsDeducted: 0, linkedProjectId: 'P001'
  },
  { 
    id: 'T1004', date: '2023-10-25', type: 'Expense', amount: -4500, description: 'Water Pumps Purchase', category: 'Project P001', 
    paymentMode: 'NEFT/RTGS', bankReference: 'UTR-9981', reconciled: false, grossAmount: 4500, tdsDeducted: 0, linkedProjectId: 'P001'
  },
  { 
    id: 'T1005', date: '2023-10-24', type: 'Donation', amount: 25000, description: 'TechCorp CSR Initiative', category: 'CSR', 
    paymentMode: 'NEFT/RTGS', bankReference: 'UTR-CSR-551', reconciled: true, grossAmount: 25000, tdsDeducted: 0, linkedProjectId: 'P002'
  },
  { 
    id: 'T1006', date: '2023-10-23', type: 'Expense', amount: -800, description: 'Volunteer Travel Reimbursement', category: 'FCRA', 
    paymentMode: 'Cash', reconciled: true, grossAmount: 800, tdsDeducted: 0, linkedProjectId: 'P001'
  },
  { 
    id: 'T1007', date: '2023-10-22', type: 'Donation', amount: 1500, description: 'Online Fundraiser', category: 'General Fund', 
    paymentMode: 'UPI', bankReference: 'UPI-9911', reconciled: true, grossAmount: 1500, tdsDeducted: 0 
  },
  { 
    id: 'T1008', date: '2023-10-20', type: 'Expense', amount: -12000, description: 'Medical Equipment Import', category: 'FCRA', 
    paymentMode: 'NEFT/RTGS', bankReference: 'UTR-IMP-11', reconciled: true, grossAmount: 12000, tdsDeducted: 0, linkedProjectId: 'P001' 
  },
  { 
    id: 'T1009', date: '2023-10-18', type: 'Expense', amount: -45000, description: 'Professional Fees - Audit', category: 'Legal & Prof', 
    paymentMode: 'NEFT/RTGS', bankReference: 'UTR-AUD-001', reconciled: false, 
    grossAmount: 50000, tdsDeducted: 5000, tdsSection: '194J' 
  },
  { 
    id: 'T1010', date: '2023-10-15', type: 'Salary', amount: -32000, description: 'Salary - Oct - Manager', category: 'Payroll', 
    paymentMode: 'NEFT/RTGS', bankReference: 'SAL-OCT-01', reconciled: true, 
    grossAmount: 35000, tdsDeducted: 3000, tdsSection: '192B' 
  },
];

export const MOCK_COMPLIANCE: ComplianceRecord[] = [
  { id: 'C1', type: 'TDS Return', period: 'Q2 2023', dueDate: '2023-10-31', status: 'Pending' },
  { id: 'C2', type: 'PF Filing', period: 'Sep 2023', dueDate: '2023-10-15', status: 'Filed', filedDate: '2023-10-12', acknowledgementNo: 'PF-991822' },
  { id: 'C3', type: 'FCRA Annual', period: 'FY 22-23', dueDate: '2023-12-31', status: 'Pending' },
];

export const MOCK_INVENTORY: InventoryItem[] = [
  { id: 'I001', name: 'Water Filtration Kits', category: 'Equipment', quantity: 45, unit: 'units', reorderLevel: 50, location: 'Warehouse A' },
  { id: 'I002', name: 'Rice (50kg bags)', category: 'Food', quantity: 120, unit: 'bags', reorderLevel: 100, location: 'Warehouse B' },
  { id: 'I003', name: 'Medical First Aid Kits', category: 'Medical', quantity: 15, unit: 'kits', reorderLevel: 20, location: 'Central Office' },
  { id: 'I004', name: 'Textbooks (Grade 1-5)', category: 'Education', quantity: 500, unit: 'books', reorderLevel: 50, location: 'Warehouse A' },
  { id: 'I005', name: 'Blankets', category: 'Shelter', quantity: 300, unit: 'units', reorderLevel: 100, location: 'Warehouse B' },
];

// --- NEW MOCK DATA FOR ADMIN PANEL ---

export const MOCK_USERS: User[] = [
  {
    id: 'U001',
    name: 'Admin User',
    email: 'admin@hhf.org',
    role: 'Admin',
    department: 'IT / HQ',
    assignedProjects: ['All'],
    accessibleModules: ['dashboard', 'beneficiaries', 'projects', 'finance', 'inventory', 'admin'],
    status: 'Active',
    permissions: {
      canCreateUsers: true,
      canApproveBudget: true,
      canSignCheques: true,
      canAccessFCRA: true,
      canViewPayroll: true,
      canApproveVendors: true,
      canVerifyStock: true
    }
  },
  {
    id: 'U002',
    name: 'Alice M.',
    email: 'alice@hhf.org',
    role: 'Program Manager',
    department: 'Programs',
    assignedProjects: ['P001', 'P002'],
    accessibleModules: ['dashboard', 'beneficiaries', 'projects'],
    status: 'Active',
    permissions: {
      canCreateUsers: false,
      canApproveBudget: false,
      canSignCheques: false,
      canAccessFCRA: true,
      canViewPayroll: false,
      canApproveVendors: true,
      canVerifyStock: true
    }
  },
  {
    id: 'U003',
    name: 'Rajeev K.',
    email: 'rajeev@hhf.org',
    role: 'Finance Officer',
    department: 'Finance',
    assignedProjects: ['All'],
    accessibleModules: ['dashboard', 'finance', 'projects', 'beneficiaries'],
    status: 'Active',
    permissions: {
      canCreateUsers: false,
      canApproveBudget: true,
      canSignCheques: true,
      canAccessFCRA: true,
      canViewPayroll: true,
      canApproveVendors: true,
      canVerifyStock: false
    }
  },
  {
    id: 'U004',
    name: 'Volunteer John',
    email: 'john@hhf.org',
    role: 'Volunteer',
    department: 'Field Ops',
    assignedProjects: ['P001'],
    accessibleModules: ['dashboard', 'beneficiaries'],
    status: 'Active',
    permissions: {
      canCreateUsers: false,
      canApproveBudget: false,
      canSignCheques: false,
      canAccessFCRA: false,
      canViewPayroll: false,
      canApproveVendors: false,
      canVerifyStock: false
    }
  },
  {
    id: 'U005',
    name: 'Deepak S.',
    email: 'deepak@hhf.org',
    role: 'Accountant',
    department: 'Finance',
    assignedProjects: ['All'],
    accessibleModules: ['dashboard', 'beneficiaries', 'projects', 'finance'],
    status: 'Active',
    permissions: {
      canCreateUsers: false,
      canApproveBudget: false,
      canSignCheques: false,
      canAccessFCRA: true,
      canViewPayroll: true,
      canApproveVendors: false,
      canVerifyStock: false
    }
  }
];

export const MOCK_ROLES: RoleDefinition[] = [
  {
    id: 'R1',
    name: 'Super Admin',
    description: 'Complete control over all modules and settings.',
    accessibleModules: ['dashboard', 'beneficiaries', 'projects', 'finance', 'inventory', 'admin'],
    permissions: {
      canCreateUsers: true, canApproveBudget: true, canSignCheques: true,
      canAccessFCRA: true, canViewPayroll: true, canApproveVendors: true, canVerifyStock: true
    }
  },
  {
    id: 'R2',
    name: 'Program Manager',
    description: 'Manages projects and beneficiaries for specific programs.',
    accessibleModules: ['dashboard', 'beneficiaries', 'projects', 'inventory'],
    permissions: {
      canCreateUsers: false, canApproveBudget: false, canSignCheques: false,
      canAccessFCRA: true, canViewPayroll: false, canApproveVendors: true, canVerifyStock: true
    }
  },
  {
    id: 'R3',
    name: 'Finance Officer',
    description: 'Handles accounts, payroll, compliance, and approvals.',
    accessibleModules: ['dashboard', 'finance', 'projects'],
    permissions: {
      canCreateUsers: false, canApproveBudget: true, canSignCheques: true,
      canAccessFCRA: true, canViewPayroll: true, canApproveVendors: true, canVerifyStock: false
    }
  },
  {
    id: 'R4',
    name: 'Volunteer',
    description: 'Field access for beneficiary data entry.',
    accessibleModules: ['dashboard', 'beneficiaries'],
    permissions: {
      canCreateUsers: false, canApproveBudget: false, canSignCheques: false,
      canAccessFCRA: false, canViewPayroll: false, canApproveVendors: false, canVerifyStock: false
    }
  },
  {
    id: 'R5',
    name: 'Accountant',
    description: 'Responsible for disbursements and daily bookkeeping.',
    accessibleModules: ['dashboard', 'beneficiaries', 'projects', 'finance'],
    permissions: {
      canCreateUsers: false, canApproveBudget: false, canSignCheques: false,
      canAccessFCRA: true, canViewPayroll: true, canApproveVendors: false, canVerifyStock: false
    }
  }
];

export const MOCK_CONTROLS: InternalControl[] = [
  {
    id: 'CTL-01', area: 'Donation Receipts', risk: 'Donations received but not recorded',
    controlActivity: 'Serially numbered system receipts; reconciliation with bank deposits; dual verification',
    owner: 'Accountant', testingMethod: 'Match 100% of bank credits to Tally receipts', status: 'Compliant'
  },
  {
    id: 'CTL-02', area: 'Donation Receipts', risk: 'Foreign donations credited to domestic bank',
    controlActivity: 'Separate FCRA account and ledger; pre-approval check of donor details',
    owner: 'Finance Head', testingMethod: 'Review FCRA bank statement vs. domestic', status: 'Compliant'
  },
  {
    id: 'CTL-03', area: 'Donation Receipts', risk: 'Misappropriation or delayed deposit',
    controlActivity: 'Two-person custody; deposit within next working day; upper limit ₹10,000',
    owner: 'Project Manager', testingMethod: 'Verify deposit slips and dates', status: 'Flagged', lastVerified: '2023-09-15'
  },
  {
    id: 'CTL-04', area: 'Project Expenditure', risk: 'Unapproved Spending',
    controlActivity: 'Approved budget per project; pre-numbered vouchers',
    owner: 'Program Head', testingMethod: 'Check vouchers vs. project code', status: 'Compliant'
  },
  {
    id: 'CTL-05', area: 'Procurement', risk: 'Vendor Collusion / High Cost',
    controlActivity: 'Minimum 3 quotations above ₹25,000',
    owner: 'Purchase Officer', testingMethod: 'Verify quotation file for top 10 purchases', status: 'Compliant'
  },
  {
    id: 'CTL-06', area: 'Payroll & HR', risk: 'Ghost Employees',
    controlActivity: 'Appointment letter + ID + attendance linkage',
    owner: 'HR Head', testingMethod: 'Verify sample staff physical presence', status: 'Pending'
  },
  {
    id: 'CTL-07', area: 'Cash & Banking', risk: 'Cash Theft',
    controlActivity: 'Imprest limit Rs. 25,000; two-person custody; surprise checks',
    owner: 'Admin Head', testingMethod: 'Surprise cash count conducted', status: 'Compliant'
  },
  {
    id: 'CTL-08', area: 'Compliance', risk: 'FCRA Violation',
    controlActivity: 'Compliance calendar; responsibility assigned for FC-4',
    owner: 'Finance Head', testingMethod: 'Verify FC-4 submission proof', status: 'Compliant'
  },
  {
    id: 'CTL-09', area: 'IT Systems', risk: 'Data Loss / Unauthorized Access',
    controlActivity: 'Quarterly internal audit by Alok & Anirudh; Action tracker reviewed',
    owner: 'Audit Committee', testingMethod: 'Review audit reports and closure', status: 'Flagged'
  }
];